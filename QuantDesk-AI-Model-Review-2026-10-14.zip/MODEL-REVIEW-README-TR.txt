QuantDesk model inceleme paketi — 14.10.2026

Bu paket Android kaynak ZIP'ini ve gerçek piyasa verisiyle yapılan eğitim/doğrulama raporunu içerir.

ÖNEMLİ: Son model adayı testleri geçemedi. Uygulama adayı tahmin üretmekte kullanmaz. Paket bir APK değildir ve güvenilir/kanıtlanmış kârlı tahmin modeli içerdiği iddiasında bulunmaz.

Dosyalar:
- QuantDesk-AI-Android-ML-v0.5.1.zip: Android kaynak kodu ve eğitim hattı
- QuantDesk-Model-Dogrulama-Raporu.md: Türkçe teknik değerlendirme
- model_report_730d_reproduced.json: son 730 günlük çalışmanın tam makine-okunur raporu
