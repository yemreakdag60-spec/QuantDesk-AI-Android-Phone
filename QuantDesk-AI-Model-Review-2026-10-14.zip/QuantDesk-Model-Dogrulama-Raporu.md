# QuantDesk yapay zekâ modeli doğrulama raporu — 14 Ekim 2026

## Sonuç

**Hiçbir aday model doğrulama eşiklerini geçmedi. Telefona doğrulanmış model olarak yayımlanmadı.** Bu bir derleme hatası değil, piyasa verisi testlerinin sonucudur. Android paketi kurulabilir; ancak doğrulamadan geçmiş model gelene kadar uygulama `NO_SIGNAL` durumunda kalmalıdır.

## Geçmiş piyasa verisiyle test

- Veri: Binance USDⓈ-M resmi genel arşivinden 15 dakikalık mumlar.
- Dönem: 14 Ekim 2024–14 Ekim 2026; 24 USDT sürekli vadeli sözleşme.
- Etiketlenen örnek: 3.320.246. TP: 1,35 ATR; zarar-kes: 1,15 ATR; tahmin ufku: 12 mum.
- Bölme: kronolojik eğitim, olasılık kalibrasyonu, eşik seçimi, bağımsız doğrulama ve son test; bölümler arasında 12 mumluk etiket aralığı. Ayrıca üç genişleyen zaman serisi testi yapıldı.
- Maliyet: temel sonuçlarda gidiş-dönüş 12 baz puan; ayrıca 20 ve 30 baz puan stres testleri. Geçmiş fonlama ve haber duyarlılığı bu modele eklenmedi.

| Test | İşlem | Kazanma oranı | İşlem başına ortalama net getiri | Kâr faktörü | 20 bp ortalama net getiri |
|---|---:|---:|---:|---:|---:|
| Kronolojik bağımsız doğrulama | 842 | %44,5 | −%0,147 | 0,646 | Başarısız |
| Son ayrılmış test dönemi | 560 | %47,9 | −%0,069 | 0,824 | Başarısız |
| Zaman serisi katı 1 | 73 | %31,5 | −%0,377 | 0,297 | −%0,457 |
| Zaman serisi katı 2 | 2.936 | %49,1 | −%0,089 | 0,782 | −%0,169 |
| Zaman serisi katı 3 | 145 | %49,7 | −%0,177 | 0,643 | −%0,257 |

Son test AUC değeri 0,527 çıktı; sınıflandırma sıralaması şansa yakın. Brier skoru 0,2426 iken yalnızca temel oranı tahmin eden basit referans modelinin skoru 0,2430 oldu. 20 baz puan maliyet varsayımında kârlı zaman serisi katı sayısı sıfır. Aday; eşik seçimi, bağımsız doğrulama, zaman serisi testleri, pozitif net getiri, güven aralığı ve maliyet stres kontrollerini geçemedi.

## Daha yakın dönemle yeniden eğitim deneyi

Aynı sınıflandırıcı, eğitim aralığı son 730, 365, 180 ve 90 gün olacak şekilde tekrar eğitildi. Kalibrasyon, eşik seçimi, doğrulama ve son test dönemleri eğitimden ayrı tutuldu. Hiçbiri geçmedi:

| Eğitim geçmişi | Doğrulama ortalama net getirisi | Son test ortalama net getirisi | Son test 20 bp ortalama net getirisi |
|---|---:|---:|---:|
| 730 gün | −%0,143 | −%0,089 | −%0,169 |
| 365 gün | −%0,503 | +%0,092 | +%0,012 |
| 180 gün | yaklaşık %0,000 | −%0,129 | −%0,209 |
| 90 gün | −%0,131 | −%0,161 | −%0,241 |

365 günlük model son testte artı görünse de ayrı doğrulamada işlem başına −%0,50 verdi; 20 bp stres payı yalnızca +%0,012 idi ve eşik seçimi kapısı da başarısız oldu. Tahmin üretmeye uygun değildir.

Doğrudan getiri tahmin eden regresyon deneyi de reddedildi: son test işlem başına ortalama net getiri −%0,125, kâr faktörü 0,751, R² −0,005 ve tahmin-gerçekleşen getiri korelasyonu −0,005 çıktı.

## Telefona yüklenen mevcut sürümün durumu

Android kaynakları mumları tarayabilir ve dış haber başlıklarını gösterebilir. Haberler yalnızca bilgi bağlamıdır; duygu analizi yapılmıyor ve modelin olasılık hesabına girmiyor. Uygulama, doğrulanmış model yokken TP olasılığı göstermeyi bilerek reddeder. Emir göndermez. APK dosyasının küçük olması kendi başına modelin yeterliliğini göstermez; mevcut sürümde doğrulamadan geçmiş gömülü model yoktur.

## Güvenilir model demeden önce gerekenler

1. Her tarih için gerçekten o anda bilinebilen geçmiş fonlama, alıcı-satıcı akışı/açık pozisyon ve güvenilir kripto/makro haber özelliklerini eklemek; gelecek bilgisi sızıntısını önlemek.
2. Adayları daha sonraki, eğitimde hiç kullanılmamış dönemlerde; ücret, fonlama, spread/kayma ve eşzamanlı pozisyonları hesaba katarak sınamak.
3. Birden fazla zaman serisi döneminde ve maliyet streslerinde tekrarlanan pozitif net getiri ve pozitif güven sınırları istemek. Bağımsız kontrol sonrası geçmeyen model `NO_SIGNAL` kalmalı.
4. Gerçek kullanım öncesi ileriye dönük gölge test yapmak. Geçmiş test tek başına gelecekte güvenilirlik kanıtı değildir.

## Dosyalar

- `model_report_730d_reproduced.json`: tam çalışmanın makine-okunur raporu; semboller, dönemler, alt grup sonuçları, maliyet stresleri ve başarısız kapılar dahildir.
- Android eğitim ve uygulama kaynakları `QuantDesk-AI-Android-ML-v0.5.1.zip` içindedir.

Bu rapor kârlı veya güvenilir tahmin yapan bir modelin bulunduğunu iddia etmez. Mevcut adayın neden reddedildiğini kayıt altına alır.
