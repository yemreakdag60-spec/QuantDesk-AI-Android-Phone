package com.emreakdag.quantdesk.ai;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

final class MarketScanner {
    private static final String BASE="https://fapi.binance.com";
    List<AiEngine.Candidate> scan(LearningStore store) throws Exception {
        store.refreshPromotedModelIfDue();
        AiEngine.Model model=store.loadModel();
        if(model==null) throw new Exception("Henüz doğrulamadan geçmiş bir ön eğitim modeli yok.");
        JSONArray info=getArray("/fapi/v1/exchangeInfo", null);
        JSONArray ticks=getArray("/fapi/v1/ticker/24hr", null);
        Set<String> eligible=new HashSet<>();
        for(int i=0;i<info.length();i++){ JSONObject s=info.getJSONObject(i); if("PERPETUAL".equals(s.optString("contractType")) && "USDT".equals(s.optString("quoteAsset")) && "TRADING".equals(s.optString("status"))) eligible.add(s.optString("symbol")); }
        List<String> symbols=new ArrayList<>();
        List<double[]> volumes=new ArrayList<>();
        for(int i=0;i<ticks.length();i++){ JSONObject t=ticks.getJSONObject(i); String s=t.optString("symbol"); double v=t.optDouble("quoteVolume",0); if(eligible.contains(s)&&v>=10_000_000){symbols.add(s);volumes.add(new double[]{v,symbols.size()-1});} }
        volumes.sort((a,b)->Double.compare(b[0],a[0]));
        List<String> top=new ArrayList<>(); for(int i=0;i<Math.min(250,volumes.size());i++) top.add(symbols.get((int)volumes.get(i)[1]));
        List<AiEngine.Candle> btc=klines("BTCUSDT");
        var pool=Executors.newFixedThreadPool(8);
        List<Future<AiEngine.Candidate>> futures=new ArrayList<>();
        for(String symbol:top){ futures.add(pool.submit((Callable<AiEngine.Candidate>)()->{
            List<AiEngine.Candle> candles=klines(symbol);
            store.observe(symbol,candles);
            AiEngine.Candidate candidate=AiEngine.analyze(symbol,candles,btc,model);
            if(candidate!=null) store.recordCandidate(candidate);
            return candidate;
        })); }
        List<AiEngine.Candidate> out=new ArrayList<>();
        try { for(Future<AiEngine.Candidate> f:futures){ try { AiEngine.Candidate c=f.get(); if(c!=null) out.add(c); } catch(Exception ignored){} } }
        finally { pool.shutdownNow(); }
        out.sort(Comparator.comparingDouble((AiEngine.Candidate c)->c.probability).reversed().thenComparing(Comparator.comparingDouble((AiEngine.Candidate c)->c.setup).reversed()));
        return out;
    }
    private List<AiEngine.Candle> klines(String symbol)throws Exception{
        // Keep enough closed bars to initialize the 100-period EMA close to
        // the long-history feature calculation used by the training pipeline.
        JSONArray a=getArray("/fapi/v1/klines", "symbol="+enc(symbol)+"&interval=15m&limit=500");
        List<AiEngine.Candle> out=new ArrayList<>(); long now=System.currentTimeMillis();
        for(int i=0;i<a.length();i++){JSONArray r=a.getJSONArray(i); if(r.getLong(6)>=now) continue; out.add(new AiEngine.Candle(r.getLong(0),r.getDouble(1),r.getDouble(2),r.getDouble(3),r.getDouble(4),r.getDouble(5)));}
        return out;
    }
    private static JSONArray getArray(String path,String query)throws Exception{
        URL url=new URL(BASE+path+(query==null?"":"?"+query)); HttpURLConnection c=(HttpURLConnection)url.openConnection(); c.setConnectTimeout(10000); c.setReadTimeout(15000); c.setRequestProperty("User-Agent","QuantDeskAI-Android/0.1");
        try { int code=c.getResponseCode(); if(code!=200) throw new Exception("Binance HTTP "+code); BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),StandardCharsets.UTF_8)); StringBuilder b=new StringBuilder(); String line; while((line=r.readLine())!=null)b.append(line); return new JSONArray(b.toString()); }
        finally { c.disconnect(); }
    }
    private static String enc(String x)throws Exception{return URLEncoder.encode(x,"UTF-8");}
}
