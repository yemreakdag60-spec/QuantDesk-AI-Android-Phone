# QuantDesk Prism — Bitcoin yön filtresi ve TP/SL düzeltmesi

Bu depo, yüklediğiniz `app-debug.apk` dosyasını temel alır. Uygulama her taramada Binance USDⓈ-M 24 saatlik USDT sözleşmelerini hacme göre sıralar ve **24 saatlik kotasyon hacmi en az 5.000.000 USDT olanların tamamını** tarar. Tarama, seçili zaman diliminde Bitcoin için yön sinyali üretir; yalnız aynı yöndeki ve en az 68/100 sinyal gücündeki coin kurulumlarını değerlendirir. Bitcoin yönü `BEKLE` ise yön filtresi gereği coin taraması durur. Uygun sözleşme sayısı borsadaki aktif piyasa ve o anki hacme bağlıdır; 500’den az uygun sözleşme bulunan durumda 500 sayısına yapay biçimde tamamlanmaz.

Önceki TP/SL düzeltmeleri korunur. APK yama betiği yalnızca aşağıdaki üyeleri değiştirir:

- `assets/prism-app.js`: 5 milyon USDT 24 saat hacim filtresi ve tüm uygun sözleşmelerin taranması; BTC yönüyle eşleşme filtresi.
- `assets/prism-engine.js`: ATR ve 12 mumluk erişilebilirlik sınırına göre TP/SL üretimi.
- `AndroidManifest.xml` içindeki paket kimliği: önceki uygulamanın yanına ayrı uygulama olarak kurulabilmesi için.

Diğer APK üyelerinin sıkıştırılmış içerikleri aynen korunur. Eski APK imza kayıtları kaldırılır ve GitHub Actions çıktısı Android Build Tools ile v1/v2/v3 imzalanır.

## GitHub'dan ayrı kurulabilir APK üretme

1. Bu arşivi açıp içindeki dosyaları yeni bir GitHub deposuna yükleyin.
2. Depoda **Actions** sekmesini açın.
3. **Build QuantDesk Prism BTC 500+ APK** iş akışını seçip **Run workflow** başlatın.
4. Tamamlanınca **QuantDesk-Prism-BTC-500** adlı artifact'i indirin; içinden APK'yı çıkarıp telefona yükleyin.

İlk derleme için imzalama sırrı tanımlamak gerekmez. Bu durumda GitHub her çalıştırmada geçici imza anahtarı oluşturur. Aynı uygulama kopyasına sonraki GitHub derlemelerini güncelleme olarak yüklemek için aynı imzalama anahtarının `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS` ve `KEY_PASSWORD` sırlarıyla saklanması gerekir. Uygulamanın paket kimliği `com.emreakdag.quantdesk.prism250newx` olarak ayarlanmıştır; görünen uygulama adı değişmemiştir.
