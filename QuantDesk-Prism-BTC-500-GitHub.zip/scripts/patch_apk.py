#!/usr/bin/env python3
"""Patch Prism scanner/TP-SL assets and package id needed for side-by-side install.
All unrelated ZIP members are copied byte-for-byte at the compressed-data level.
"""
from __future__ import annotations
import argparse
import binascii
import struct
import tempfile
import zlib
from pathlib import Path
from zipfile import ZipFile

LOCAL = struct.Struct('<IHHHHHIIIHH')
CENTRAL = struct.Struct('<IHHHHHHIIIHHHHHII')
EOCD = struct.Struct('<IHHHHIIH')
OLD_PACKAGE = 'com.emreakdag.quantdesk.prism250news'
NEW_PACKAGE = 'com.emreakdag.quantdesk.prism250newx'  # separate install, same byte length
REMOVED_SIGNATURES = {'META-INF/MANIFEST.MF', 'META-INF/CERT.SF', 'META-INF/CERT.RSA'}
PATCHED = {'assets/prism-engine.js', 'assets/prism-app.js', 'AndroidManifest.xml'}


def deflate(data: bytes) -> bytes:
    obj = zlib.compressobj(level=6, method=zlib.DEFLATED, wbits=-15)
    return obj.compress(data) + obj.flush()


def patch_manifest(data: bytes) -> bytes:
    old, new = OLD_PACKAGE.encode('utf-16le'), NEW_PACKAGE.encode('utf-16le')
    if len(old) != len(new) or data.count(old) != 1:
        raise ValueError('AndroidManifest.xml package string was not found exactly once at the expected length')
    return data.replace(old, new)


def local_record(apk: bytes, info, replacement: bytes | None) -> tuple[bytes, int, int, int]:
    off = info.header_offset
    fields = LOCAL.unpack_from(apk, off)
    if fields[0] != 0x04034B50:
        raise ValueError(f'Invalid local ZIP header: {info.filename}')
    _, version, flags, method, mtime, mdate, crc, csize, usize, name_len, extra_len = fields
    start = off + LOCAL.size
    name = apk[start:start + name_len]
    extra = apk[start + name_len:start + name_len + extra_len]
    data_start = start + name_len + extra_len
    if replacement is None:
        data_end = data_start + info.compress_size
        if flags & 0x0008:
            descriptor = data_end
            if apk[descriptor:descriptor + 4] == b'PK\x07\x08':
                data_end += 16
            else:
                data_end += 12
        return apk[off:data_end], crc, info.compress_size, info.file_size
    if flags & 0x0008:
        raise ValueError('Unexpected data descriptor on patched member')
    if method == 0:
        compressed = replacement
    elif method == 8:
        compressed = deflate(replacement)
    else:
        raise ValueError(f'Unsupported ZIP compression method {method} for {info.filename}')
    crc = binascii.crc32(replacement) & 0xffffffff
    csize, usize = len(compressed), len(replacement)
    header = LOCAL.pack(0x04034B50, version, flags, method, mtime, mdate, crc, csize, usize, len(name), len(extra))
    return header + name + extra + compressed, crc, csize, usize


def patch(base: Path, assets: Path, output: Path) -> None:
    apk = base.read_bytes()
    with ZipFile(base) as zin:
        infos = zin.infolist()
        old_names = {i.filename for i in infos}
        if not PATCHED <= old_names:
            raise ValueError('The uploaded APK does not contain the expected Prism files')
        replacements = {
            'assets/prism-engine.js': (assets / 'prism-engine.js').read_bytes(),
            'assets/prism-app.js': (assets / 'prism-app.js').read_bytes(),
            'AndroidManifest.xml': patch_manifest(zin.read('AndroidManifest.xml')),
        }
        eocd_pos = apk.rfind(b'PK\x05\x06')
        if eocd_pos < 0:
            raise ValueError('ZIP end-of-central-directory record not found')
        end = EOCD.unpack_from(apk, eocd_pos)
        if end[-1] != 0:
            raise ValueError('Unexpected ZIP comment')
        cd_start = zin.start_dir
        cd_end = cd_start + end[5]
        if cd_end != eocd_pos:
            raise ValueError('Unexpected APK signing or ZIP layout')

        local_bytes = bytearray()
        central_bytes = bytearray()
        for info in infos:
            central_head = CENTRAL.unpack_from(apk, cd_start)
            if central_head[0] != 0x02014B50:
                raise ValueError(f'Invalid central-directory record: {info.filename}')
            fn_len, ex_len, comment_len = central_head[10], central_head[11], central_head[12]
            full_len = CENTRAL.size + fn_len + ex_len + comment_len
            old_central = apk[cd_start:cd_start + full_len]
            cd_start += full_len
            if info.filename in REMOVED_SIGNATURES:
                continue
            replacement = replacements.get(info.filename)
            record, crc, csize, usize = local_record(apk, info, replacement)
            new_offset = len(local_bytes)
            local_bytes.extend(record)

            central = bytearray(old_central[:CENTRAL.size])
            fields = CENTRAL.unpack(central)
            central = bytearray(old_central)
            struct.pack_into('<I', central, 16, crc)
            struct.pack_into('<I', central, 20, csize)
            struct.pack_into('<I', central, 24, usize)
            struct.pack_into('<I', central, 42, new_offset)
            central_bytes.extend(central)

        if cd_start != cd_end:
            raise ValueError('Central-directory entries did not end at the expected boundary')
        new_cd_offset = len(local_bytes)
        new_eocd = list(end)
        new_count = len(infos) - sum(n in REMOVED_SIGNATURES for n in old_names)
        new_eocd[3] = new_count
        new_eocd[4] = new_count
        new_eocd[5] = len(central_bytes)
        new_eocd[6] = new_cd_offset
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(local_bytes + central_bytes + EOCD.pack(*new_eocd))

    # Verify the byte content of every untouched member and ensure only intended changes remain.
    with ZipFile(base) as before, ZipFile(output) as after:
        expected_names = old_names - REMOVED_SIGNATURES
        if set(after.namelist()) != expected_names:
            raise ValueError('APK member list changed outside removal of old signature records')
        for name in expected_names - PATCHED:
            if before.read(name) != after.read(name):
                raise ValueError(f'Unexpected content change: {name}')
        for name, data in replacements.items():
            if after.read(name) != data:
                raise ValueError(f'Patched content verification failed: {name}')
    print(f'Patched {len(PATCHED)} members; preserved {len(expected_names - PATCHED)} other members.')
    print(f'Package id: {OLD_PACKAGE} -> {NEW_PACKAGE}')
    print(f'Unsigned APK: {base.stat().st_size} -> {output.stat().st_size} bytes')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--base', type=Path, default=Path('base/app-debug.apk'))
    parser.add_argument('--assets', type=Path, default=Path('assets'))
    parser.add_argument('--output', type=Path, default=Path('build/QuantDesk-Prism-BTC-500-unsigned.apk'))
    args = parser.parse_args()
    patch(args.base, args.assets, args.output)
