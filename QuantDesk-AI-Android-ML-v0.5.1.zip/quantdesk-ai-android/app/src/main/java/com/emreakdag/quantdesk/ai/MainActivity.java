package com.emreakdag.quantdesk.ai;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.text.util.Linkify;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final AtomicBoolean scanBusy = new AtomicBoolean(false);
    private ScheduledExecutorService timer;
    private TextView status;
    private TextView results;
    private TextView headlines;
    private Button toggle;
    private final MarketScanner scanner = new MarketScanner();
    private final NewsResearch newsResearch = new NewsResearch();
    private LearningStore store;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        store = new LearningStore(this);
        buildUi();
        refreshSummary();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 16);
        root.setBackgroundColor(Color.rgb(11, 18, 32));
        TextView title = new TextView(this);
        title.setText("QUANTDESK AI"); title.setTextSize(25); title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title);
        status = new TextView(this);
        status.setTextColor(Color.rgb(175, 190, 210)); status.setTextSize(14); status.setPadding(0, 12, 0, 16);
        root.addView(status);
        toggle = new Button(this); toggle.setText("TARAMAYI BAŞLAT");
        toggle.setOnClickListener(v -> toggleScan()); root.addView(toggle);
        TextView note = new TextView(this);
        note.setText("Binance USDⓈ-M • Modelin eğitim evrenindeki sözleşmeler • 24 saatlik hacim ≥ 10M USDT • 15 dk mum\nUygulama açıkken 60 saniyede bir tarar. Gerçek emir göndermez.");
        note.setTextColor(Color.rgb(145, 163, 185)); note.setTextSize(12); note.setPadding(0, 10, 0, 10);
        root.addView(note);
        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        results = new TextView(this); results.setTextColor(Color.WHITE); results.setTextSize(14); results.setPadding(0, 8, 0, 20);
        headlines = new TextView(this); headlines.setTextColor(Color.rgb(210,220,232)); headlines.setTextSize(13); headlines.setPadding(0, 12, 0, 24);
        headlines.setAutoLinkMask(Linkify.WEB_URLS); headlines.setLinkTextColor(Color.rgb(90,170,255));
        content.addView(results); content.addView(headlines); scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void toggleScan() { if (running.get()) stopScan(); else startScan(); }

    private void startScan() {
        if (!running.compareAndSet(false, true)) return;
        toggle.setText("DURDUR");
        status.setText("Binance verisi bekleniyor… İlk tarama biraz sürebilir.");
        timer = Executors.newSingleThreadScheduledExecutor();
        timer.scheduleWithFixedDelay(() -> {
            if (scanBusy.compareAndSet(false, true)) worker.submit(() -> { try { scanOnce(); } finally { scanBusy.set(false); } });
        }, 0, 60, TimeUnit.SECONDS);
    }

    private void stopScan() {
        running.set(false);
        if (timer != null) timer.shutdownNow();
        toggle.setText("TARAMAYI BAŞLAT");
        status.setText("Tarama durduruldu. Gölge sonuçları telefonda saklanıyor; model güncellemeleri doğrulanırsa alınır.");
    }

    private void scanOnce() {
        List<AiEngine.Candidate> candidates=new java.util.ArrayList<>();
        String scanError=null;
        try { candidates=scanner.scan(store); }
        catch(Exception e) { scanError=safeMessage(e); }
        List<NewsResearch.Headline> news;
        String newsError=null;
        try { news=newsResearch.fetchIfDue(); }
        catch(Exception e) { news=new java.util.ArrayList<>(); newsError=safeMessage(e); }
        final List<AiEngine.Candidate> fetchedCandidates=candidates;
        final List<NewsResearch.Headline> fetchedNews=news;
        final String failedNews=newsError, failedScan=scanError;
        main.post(() -> render(fetchedCandidates,fetchedNews,failedNews,failedScan));
    }

    private void render(List<AiEngine.Candidate> candidates, List<NewsResearch.Headline> news, String newsError, String scanError) {
        if (isFinishing()) return;
        int labeled = store.labeledCount();
        AiEngine.Model model = store.loadModel();
        String readiness = model == null ? "DOĞRULANMIŞ MODEL YOK" : "MODEL " + model.id.substring(0, Math.min(10, model.id.length()));
        status.setText("Tarama çalışıyor • " + readiness + " • Tamamlanan gölge sonuç: " + labeled);
        if (scanError!=null) results.setText("Piyasa taraması yapılamadı: "+scanError+"\n\nModel doğrulama eşiğini geçmeden tahmin gösterilmez.");
        else if (candidates.isEmpty()) results.setText("Bu taramada eşik üstü aday bulunmadı.\n\nBu normaldir; sistem yapay fırsat üretmez.");
        else {
        StringBuilder b = new StringBuilder();
        for (AiEngine.Candidate c : candidates) {
            b.append(c.symbol).append("  ").append(c.side).append("\n");
            b.append("Kurulum puanı: ").append(String.format(java.util.Locale.US, "%.0f", c.setup * 100)).append("/100\n");
            b.append("Giriş referansı: ").append(fmt(c.entry)).append("\nTP1: ").append(fmt(c.tp1)).append("\nStop: ").append(fmt(c.stop)).append("\n");
            if (c.probability >= 0) b.append("Model TP1 olasılık tahmini: ").append(String.format(java.util.Locale.US, "%.1f%%", c.probability * 100)).append("\n");
            else b.append("Gölge kayıt: sonuç bekleniyor; doğrulanmış model olasılığı henüz yok.\n");
            b.append("────────────────────────\n");
        }
        results.setText(b.toString());
        }
        StringBuilder n=new StringBuilder("HABER BAĞLAMI — son 24 saat\n");
        if(newsError!=null && news.isEmpty()) n.append("Haber akışı alınamadı: ").append(newsError).append("\n");
        else if(news.isEmpty()) n.append("Eşleşen başlık bulunamadı.\n");
        else for(NewsResearch.Headline h:news) n.append("\n• ").append(h.title).append("\n").append(h.domain).append(" • ").append(h.date).append("\n").append(h.url).append("\n");
        n.append("\nBaşlıklar kaynak bağlamıdır; doğrulanmış model girdisi veya işlem tavsiyesi değildir.");
        headlines.setText(n.toString());
    }

    private void refreshSummary() { status.setText("Hazır • Doğrulanmış model: " + (store.loadModel() == null ? "yok" : "var") + " • Gölge sonuç kaydı: " + store.labeledCount()); }
    private static String fmt(double v) { return String.format(java.util.Locale.US, "%.8f", v).replaceAll("0+$", "").replaceAll("\\.$", ""); }
    private static String safeMessage(Exception e) { String s=e.getMessage(); return s==null?"bağlantı hatası":s; }

    @Override protected void onStop() { if (running.get()) stopScan(); super.onStop(); }
    @Override protected void onDestroy() { worker.shutdownNow(); super.onDestroy(); }
}
