package com.emreakdag.quantdesk.ai;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

/** Fetches recent crypto and macro headlines; headlines remain context, not model inputs. */
final class NewsResearch {
    static final class Headline {
        final String title, domain, date, url;
        Headline(String t, String d, String when, String link) { title=t; domain=d; date=when; url=link; }
    }
    private long lastFetchMs;
    private List<Headline> cached = new ArrayList<>();

    synchronized List<Headline> fetchIfDue() throws Exception {
        if (lastFetchMs>0 && System.currentTimeMillis()-lastFetchMs < 10*60*1000L) return cached;
        // Throttle even empty/error responses so a quiet news window or HTTP 429
        // cannot cause a new public API request every scan cycle.
        lastFetchMs=System.currentTimeMillis();
        List<Headline> next=new ArrayList<>();
        List<String> errors=new ArrayList<>();
        try { next.addAll(fetchGdelt()); } catch(Exception e) { errors.add("GDELT: "+e.getMessage()); }
        try { next.addAll(fetchRss("https://www.federalreserve.gov/feeds/press_all.xml", "Federal Reserve", 5, true)); }
        catch(Exception e) { errors.add("Fed RSS: "+e.getMessage()); }
        try { next.addAll(fetchRss("https://www.sec.gov/news/pressreleases.rss", "SEC", 5, false)); }
        catch(Exception e) { errors.add("SEC RSS: "+e.getMessage()); }
        if(next.isEmpty() && !errors.isEmpty()) throw new Exception(String.join("; ", errors));
        cached=next; return cached;
    }

    private List<Headline> fetchGdelt() throws Exception {
        String query = "(bitcoin OR cryptocurrency OR crypto OR ethereum) AND (Federal Reserve OR Fed OR interest rate OR inflation OR ETF OR regulation OR hack)";
        String address = "https://api.gdeltproject.org/api/v2/doc/doc?query=" + URLEncoder.encode(query, "UTF-8") +
                "&mode=ArtList&format=json&maxrecords=12&sort=HybridRel&timespan=24h";
        HttpURLConnection c=open(address);
        try {
            if(c.getResponseCode()!=200) throw new Exception("HTTP "+c.getResponseCode());
            StringBuilder body=readBody(c);
            JSONArray articles=new JSONObject(body.toString()).optJSONArray("articles");
            List<Headline> out=new ArrayList<>();
            if(articles!=null) for(int i=0;i<articles.length() && out.size()<12;i++) {
                JSONObject a=articles.optJSONObject(i); if(a==null) continue;
                String title=a.optString("title","").trim(), url=a.optString("url","").trim();
                if(!title.isEmpty() && url.startsWith("https://")) out.add(new Headline(title,a.optString("domain","GDELT"),a.optString("seendate",""),url));
            }
            return out;
        } finally { c.disconnect(); }
    }

    private List<Headline> fetchRss(String address, String source, int limit, boolean macroFeed) throws Exception {
        HttpURLConnection c=open(address);
        try {
            if(c.getResponseCode()!=200) throw new Exception("HTTP "+c.getResponseCode());
            XmlPullParser parser=XmlPullParserFactory.newInstance().newPullParser();
            parser.setInput(c.getInputStream(), "UTF-8");
            List<Headline> out=new ArrayList<>();
            String title=null, link=null, date=null, field=null;
            int event=parser.getEventType();
            while(event!=XmlPullParser.END_DOCUMENT && out.size()<limit) {
                if(event==XmlPullParser.START_TAG) {
                    field=parser.getName();
                    if("item".equals(field)) { title=null; link=null; date=null; }
                } else if(event==XmlPullParser.TEXT && field!=null) {
                    if("title".equals(field)) title=parser.getText().trim();
                    else if("link".equals(field)) link=parser.getText().trim();
                    else if("pubDate".equals(field)) date=parser.getText().trim();
                } else if(event==XmlPullParser.END_TAG) {
                    String tag=parser.getName();
                    if("item".equals(tag) && title!=null && link!=null) {
                        String lower=title.toLowerCase(java.util.Locale.ROOT);
                        boolean relevant=macroFeed || lower.contains("bitcoin") || lower.contains("crypto") || lower.contains("digital asset") || lower.contains("etf") || lower.contains("blockchain");
                        if(relevant && link.startsWith("https://")) out.add(new Headline(title,source,date==null?"":date,link));
                        title=null; link=null; date=null;
                    }
                    field=null;
                }
                event=parser.next();
            }
            return out;
        } finally { c.disconnect(); }
    }

    private static HttpURLConnection open(String address) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();
        c.setConnectTimeout(8000); c.setReadTimeout(10000); c.setRequestProperty("User-Agent","QuantDeskAI-Android/0.3");
        return c;
    }
    private static StringBuilder readBody(HttpURLConnection c) throws Exception {
        StringBuilder body=new StringBuilder();
        try(BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
            String line; while((line=r.readLine())!=null) body.append(line);
        }
        return body;
    }
}
