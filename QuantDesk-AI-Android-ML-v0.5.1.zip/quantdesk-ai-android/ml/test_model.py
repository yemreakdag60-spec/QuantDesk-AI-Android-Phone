import importlib.util
import datetime as dt
import pathlib
import unittest

import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier

SCRIPT = pathlib.Path(__file__).with_name("train_model.py")
spec = importlib.util.spec_from_file_location("quantdesk_train_model", SCRIPT)
trainer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(trainer)


class TrainingPipelineTests(unittest.TestCase):
    def test_archive_source_uses_official_um_paths_and_closed_daily_files(self):
        urls = trainer._archive_urls(
            "BTCUSDT", dt.date(2026, 8, 29),
            dt.date(2026, 10, 13), dt.date(2026, 10, 13),
        )
        self.assertTrue(any("/monthly/klines/BTCUSDT/15m/BTCUSDT-15m-2026-08.zip" in u for u in urls))
        self.assertTrue(any("/daily/klines/BTCUSDT/15m/BTCUSDT-15m-2026-09-01.zip" in u for u in urls))
        self.assertTrue(any("/daily/klines/BTCUSDT/15m/BTCUSDT-15m-2026-10-12.zip" in u for u in urls))
        self.assertFalse(any("2026-10-13.zip" in u for u in urls))

    def test_exported_tree_inference_matches_sklearn(self):
        rng = np.random.default_rng(31)
        x = rng.normal(size=(1600, len(trainer.FEATURES))).astype(np.float32)
        y = (x[:, 0] - 0.4 * x[:, 1] + rng.normal(size=len(x)) * 0.7 > 0).astype(np.uint8)
        model = HistGradientBoostingClassifier(
            max_iter=18, max_leaf_nodes=7, min_samples_leaf=20,
            learning_rate=0.05, early_stopping=False, random_state=7,
        ).fit(x[:1200], y[:1200])
        exported = {
            "baseline": float(model._baseline_prediction[0, 0]),
            "learning_rate": 1.0,
            "trees": [trainer.export_tree(stage[0]) for stage in model._predictors],
        }
        actual = trainer.exported_raw(exported, x[1200:])
        expected = model.decision_function(x[1200:])
        np.testing.assert_allclose(actual, expected, atol=1e-6, rtol=0)

    def test_training_and_probability_calibration_run_end_to_end(self):
        rng = np.random.default_rng(33)
        x = rng.normal(size=(5600, len(trainer.FEATURES))).astype(np.float32)
        latent = 0.9 * x[:, 0] - 0.5 * x[:, 1] + 0.25 * x[:, 12]
        y = (latent + rng.normal(size=len(x)) > 0).astype(np.uint8)
        exported, _ = trainer.fit_and_export(x[:4000], y[:4000], x[4000:], y[4000:])
        p = trainer.model_prob(exported, x[4000:])
        self.assertTrue(np.isfinite(p).all())
        self.assertTrue(((p >= 0) & (p <= 1)).all())
        self.assertEqual(len(exported["trees"]), 180)

    def test_features_are_finite_and_directional_schema_matches(self):
        rng = np.random.default_rng(32)
        n = 1600
        ts = np.arange(n, dtype=np.int64) * trainer.BAR_MS + 1_700_000_000_000
        close = 100 * np.exp(np.cumsum(rng.normal(0.0001, 0.004, n)))
        op = np.r_[close[0], close[:-1]]
        high = np.maximum(op, close) * (1 + rng.uniform(0, 0.002, n))
        low = np.minimum(op, close) * (1 - rng.uniform(0, 0.002, n))
        volume = rng.lognormal(4, 0.5, n)
        raw = np.column_stack([ts, op, high, low, close, volume])
        base, candle_ts = trainer.feature_frame(raw, {})
        btc = {
            int(t): (float(base[i, 0]), float(base[i, 1]), float(base[i, 3]), float(base[i, 9]))
            for i, t in enumerate(candle_ts) if i >= 12
        }
        x, y, returns, sample_ts, symbols = trainer.build_samples(raw, btc, 1)
        self.assertEqual(x.shape[1], len(trainer.FEATURES))
        self.assertTrue(np.isfinite(x).all())
        self.assertEqual(len(x), len(y))
        self.assertEqual(len(x), len(returns))
        self.assertTrue(set(np.unique(y)).issubset({0, 1}))

    def test_chronological_windows_have_embargo_gaps(self):
        ts = np.arange(20_000, dtype=np.int64) * trainer.BAR_MS
        windows = trainer.split_windows(ts)
        train_end = ts[windows["train"]].max()
        cal_start = ts[windows["cal"]].min()
        cal_end = ts[windows["cal"]].max()
        select_start = ts[windows["select"]].min()
        select_end = ts[windows["select"]].max()
        validation_start = ts[windows["validation"]].min()
        validation_end = ts[windows["validation"]].max()
        test_start = ts[windows["test"]].min()
        self.assertGreaterEqual(cal_start - train_end, 2 * trainer.HORIZON * trainer.BAR_MS)
        self.assertGreaterEqual(select_start - cal_end, 2 * trainer.HORIZON * trainer.BAR_MS)
        self.assertGreaterEqual(validation_start - select_end, 2 * trainer.HORIZON * trainer.BAR_MS)
        self.assertGreaterEqual(test_start - validation_end, 2 * trainer.HORIZON * trainer.BAR_MS)

    def test_rolling_folds_are_ordered_and_embargoed(self):
        ts = np.arange(500_000, dtype=np.int64) * trainer.BAR_MS
        folds = trainer.rolling_fold_windows(ts)
        self.assertEqual(len(folds), 3)
        previous_eval_start = -1
        for fold in folds:
            train_end = ts[fold["train"]].max()
            cal_start = ts[fold["cal"]].min()
            cal_end = ts[fold["cal"]].max()
            select_start = ts[fold["select"]].min()
            select_end = ts[fold["select"]].max()
            eval_start = ts[fold["evaluation"]].min()
            self.assertGreaterEqual(cal_start - train_end, 2 * trainer.HORIZON * trainer.BAR_MS)
            self.assertGreaterEqual(select_start - cal_end, 2 * trainer.HORIZON * trainer.BAR_MS)
            self.assertGreaterEqual(eval_start - select_end, 2 * trainer.HORIZON * trainer.BAR_MS)
            self.assertGreater(eval_start, previous_eval_start)
            previous_eval_start = eval_start

    def test_cost_stress_subtracts_extra_round_trip_cost(self):
        rows = [(i * 86_400_000, 0, 0.8, 0.003) for i in range(20)]
        stress = trainer.cost_stress_metrics(rows)
        base = stress["total_12_bps"]["net_mean"]
        twenty = stress["total_20_bps"]["net_mean"]
        thirty = stress["total_30_bps"]["net_mean"]
        self.assertAlmostEqual(base - twenty, 0.0008, places=8)
        self.assertAlmostEqual(base - thirty, 0.0018, places=8)

    def test_portfolio_metrics_do_not_compound_simultaneous_full_equity_trades(self):
        same_day = [(0, symbol, 0.8, -0.01) for symbol in range(20)]
        metrics = trainer.portfolio_metrics(same_day)
        # Equal 1/20 portfolio slots mean twenty concurrent -1% trades lose
        # 1% of portfolio equity, not 18% from sequential full-equity compounding.
        self.assertAlmostEqual(metrics["max_drawdown"], 0.01, places=10)

    def test_segment_report_contains_direction_symbol_and_volatility(self):
        n = 80
        probabilities = np.full(n, 0.8)
        returns = np.full(n, 0.002)
        timestamps = np.arange(n, dtype=np.int64) * (trainer.HORIZON + 1) * trainer.BAR_MS
        symbols = np.repeat([0, 1], n // 2)
        sides = np.tile(np.r_[np.ones(n // 4), -np.ones(n // 4)], 2)
        volatility = np.linspace(0.001, 0.02, n)
        report = trainer.segment_diagnostics(
            probabilities, returns, timestamps, symbols, sides, volatility,
            ["BTCUSDT", "ETHUSDT"], 0.7)
        self.assertEqual(set(report["by_direction"]), {"long", "short"})
        self.assertEqual(set(report["by_symbol"]), {"BTCUSDT", "ETHUSDT"})
        self.assertEqual(len(report["by_volatility_quartile"]), 4)

    def test_threshold_backtest_keeps_higher_probability_direction(self):
        same_symbol_time = [
            (0, 3, 0.72, -0.01), (0, 3, 0.86, 0.02),
            (trainer.HORIZON * trainer.BAR_MS, 3, 0.80, 0.01),
        ]
        rows = trainer.non_overlapping(same_symbol_time, 0.70)
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0][2], 0.86)

    def test_failed_threshold_search_reports_best_observed_trades(self):
        n=200
        probability=np.full(n,0.55)
        labels=np.zeros(n,dtype=np.uint8)
        returns=np.full(n,-0.001,dtype=np.float32)
        timestamps=np.arange(n,dtype=np.int64)*96*trainer.BAR_MS
        symbols=np.zeros(n,dtype=np.int16)
        _,metrics=trainer.choose_threshold(probability,labels,returns,timestamps,symbols)
        self.assertFalse(metrics["selection_gate_passed"])
        self.assertGreaterEqual(metrics["trades"],120)
        self.assertLess(metrics["net_mean"],0)


if __name__ == "__main__":
    unittest.main()
