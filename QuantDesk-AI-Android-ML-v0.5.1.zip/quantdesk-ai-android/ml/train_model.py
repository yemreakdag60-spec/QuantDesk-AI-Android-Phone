#!/usr/bin/env python3
"""Train and independently evaluate QuantDesk's 15m TP-before-SL model.

The script downloads public Binance USD-M perpetual OHLCV, builds labels without
using future features, trains a histogram gradient-boosted tree model, calibrates
its probabilities on a later period, chooses a threshold on a separate period,
and evaluates on a final untouched chronological holdout. It refuses to create
an eligible model when that holdout fails conservative gates.
"""

from __future__ import annotations

import argparse
import calendar
import concurrent.futures
import csv
import datetime as dt
import hashlib
import http.client
import io
import json
import math
import os
import sys
import time
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss, log_loss, roc_auc_score

BASE = "https://fapi.binance.com"
ARCHIVE_BASE = "https://data.binance.vision/data/futures/um"
ARCHIVE_BASES = (
    "https://data.binance.vision",
    "https://s3-ap-northeast-1.amazonaws.com/data.binance.vision",
)
INTERVAL = "15m"
BAR_MS = 15 * 60 * 1000
HORIZON = 12
TP_ATR = 1.35
SL_ATR = 1.15
ROUND_TRIP_COST = 0.0012  # Conservative 12 bps scenario; excludes funding.
FEATURES = [
    "side_sign", "side_ret_1", "side_ret_3", "side_ret_6", "side_ret_12",
    "side_ret_24", "side_ret_48", "side_ema20_gap", "side_ema50_gap",
    "side_ema100_gap", "side_ema20_50_gap", "side_rsi", "atr_pct", "volume_ratio",
    "side_candle_body_atr", "side_close_location", "range20_atr", "side_btc_ret_1",
    "side_btc_ret_3", "side_btc_ret_12", "side_btc_ema20_50_gap", "hour_sin",
    "hour_cos", "weekday_sin", "weekday_cos",
]

# Stable, liquid USDT perpetuals. Using a declared list avoids exchangeInfo and
# ticker API calls, which are blocked from some hosted CI regions. Symbols with
# no archive or too little history are skipped and reported.
ARCHIVE_SYMBOLS = [
    "BTCUSDT", "ETHUSDT", "BNBUSDT", "XRPUSDT", "SOLUSDT", "ADAUSDT",
    "DOGEUSDT", "TRXUSDT", "LINKUSDT", "DOTUSDT", "LTCUSDT", "BCHUSDT",
    "AVAXUSDT", "UNIUSDT", "ETCUSDT", "NEARUSDT", "APTUSDT", "ARBUSDT",
    "OPUSDT", "ATOMUSDT", "FILUSDT", "AAVEUSDT", "SUIUSDT", "TONUSDT",
]
ARCHIVE_CACHE = Path(tempfile.gettempdir()) / "quantdesk-binance-archive-cache"


def _get_json(path: str, params: dict | None = None, tries: int = 6):
    query = urllib.parse.urlencode(params or {})
    url = BASE + path + ("?" + query if query else "")
    for attempt in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "QuantDeskModelTrainer/0.2"})
            with urllib.request.urlopen(req, timeout=25) as response:
                return json.loads(response.read())
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
            if attempt == tries - 1:
                raise RuntimeError(f"Binance request failed: {path}: {exc}") from exc
            time.sleep(min(2 ** attempt, 20))


def select_symbols(limit: int) -> list[str]:
    return ARCHIVE_SYMBOLS[:max(1, min(limit, len(ARCHIVE_SYMBOLS)))]


def _month_start(year: int, month: int) -> dt.date:
    return dt.date(year, month, 1)


def _next_month(day: dt.date) -> dt.date:
    return dt.date(day.year + (day.month == 12), day.month % 12 + 1, 1)


def _archive_urls(symbol: str, start: dt.date, end: dt.date, today: dt.date) -> list[str]:
    """Monthly archives for older data; daily archives for the latest two months.

    Binance publishes daily files on the following day and monthly files on the
    first Monday. Daily files for the recent window keep training reasonably
    current even before the latest monthly file has been published.
    """
    recent_month = dt.date(today.year, today.month, 1)
    prev_month = dt.date(today.year - (today.month == 1), (today.month - 2) % 12 + 1, 1)
    daily_from = prev_month
    urls: list[str] = []
    cursor = dt.date(start.year, start.month, 1)
    while cursor <= end:
        if cursor >= daily_from:
            day = max(cursor, start)
            last = min(end, dt.date(cursor.year, cursor.month, calendar.monthrange(cursor.year, cursor.month)[1]))
            while day <= last:
                # Today's daily archive is not complete/published yet.
                if day < today:
                    name = f"{symbol}-{INTERVAL}-{day:%Y-%m-%d}.zip"
                    urls.append(f"{ARCHIVE_BASE}/daily/klines/{symbol}/{INTERVAL}/{name}")
                day += dt.timedelta(days=1)
        else:
            name = f"{symbol}-{INTERVAL}-{cursor:%Y-%m}.zip"
            urls.append(f"{ARCHIVE_BASE}/monthly/klines/{symbol}/{INTERVAL}/{name}")
        cursor = _next_month(cursor)
    return urls


def _download_archive(url: str) -> list[list[float]]:
    relpath = url.split("data.binance.vision", 1)[-1]
    ARCHIVE_CACHE.mkdir(parents=True, exist_ok=True)
    cache_file = ARCHIVE_CACHE / (hashlib.sha256(url.encode()).hexdigest() + ".zip")
    last_error: Exception | None = None
    for host in ARCHIVE_BASES:
        for attempt in range(3):
            cached = cache_file.exists()
            try:
                if cached:
                    payload = cache_file.read_bytes()
                else:
                    req = urllib.request.Request(host + relpath, headers={"User-Agent": "QuantDeskModelTrainer/0.3"})
                    with urllib.request.urlopen(req, timeout=45) as response:
                        payload = response.read()
                with zipfile.ZipFile(io.BytesIO(payload)) as archive:
                    members = [name for name in archive.namelist() if name.lower().endswith(".csv")]
                    if not members:
                        raise RuntimeError(f"Archive has no CSV: {host + relpath}")
                    if not cached:
                        cache_file.write_bytes(payload)
                    rows = []
                    with archive.open(members[0]) as data:
                        for row in csv.reader(io.TextIOWrapper(data, encoding="utf-8")):
                            if len(row) < 6:
                                continue
                            try:
                                ts = int(float(row[0]))
                                # USD-M archives use milliseconds; tolerate microsecond files too.
                                if ts > 100_000_000_000_000:
                                    ts //= 1000
                                rows.append([ts, *[float(row[i]) for i in range(1, 6)]])
                            except (ValueError, IndexError):  # Header row
                                continue
                    return rows
            except urllib.error.HTTPError as exc:
                last_error = exc
                if exc.code == 404:
                    break  # Try the official S3 endpoint before declaring the file absent.
                if attempt < 2:
                    time.sleep(1.5 * (attempt + 1))
            except (urllib.error.URLError, TimeoutError, http.client.IncompleteRead,
                    http.client.HTTPException, zipfile.BadZipFile, OSError) as exc:
                last_error = exc
                if cached:
                    cache_file.unlink(missing_ok=True)
                if attempt < 2:
                    time.sleep(1.5 * (attempt + 1))
    if isinstance(last_error, urllib.error.HTTPError) and last_error.code == 404:
        return []  # Symbol not listed yet / daily file not published on either endpoint.
    raise RuntimeError(f"Binance archive unavailable via official hosts: {url}: {last_error}") from last_error


def fetch_klines(symbol: str, start_ms: int, end_ms: int) -> np.ndarray:
    start = dt.datetime.fromtimestamp(start_ms / 1000, dt.timezone.utc).date()
    end = dt.datetime.fromtimestamp(end_ms / 1000, dt.timezone.utc).date()
    urls = _archive_urls(symbol, start, end, dt.datetime.now(dt.timezone.utc).date())
    rows: list[list[float]] = []
    # Archive downloads are independent; bounded parallelism keeps CI runtime
    # practical while avoiding an excessive burst to Binance's static-data host.
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        for part in pool.map(_download_archive, urls):
            rows.extend(part)
    if not rows:
        return np.empty((0, 6), dtype=np.float64)
    raw = np.asarray(rows, dtype=np.float64)
    raw = raw[np.argsort(raw[:, 0])]
    _, unique_idx = np.unique(raw[:, 0], return_index=True)
    raw = raw[np.sort(unique_idx)]
    return raw[(raw[:, 0] >= start_ms) & (raw[:, 0] + BAR_MS <= end_ms + 1)]


def _ema(values: np.ndarray, span: int) -> np.ndarray:
    out = np.full(values.shape, np.nan, dtype=np.float64)
    if len(values) < span:
        return out
    out[span - 1] = np.mean(values[:span])
    alpha = 2.0 / (span + 1.0)
    for i in range(span, len(values)):
        out[i] = alpha * values[i] + (1 - alpha) * out[i - 1]
    return out


def feature_frame(raw: np.ndarray, btc_by_ts: dict[int, tuple[float, float, float, float]]) -> tuple[np.ndarray, np.ndarray]:
    ts, op, hi, lo, cl, vol = raw.T
    n = len(raw)
    prev = np.r_[np.nan, cl[:-1]]
    tr = np.maximum(hi - lo, np.maximum(np.abs(hi - prev), np.abs(lo - prev)))
    atr = np.full(n, np.nan)
    for i in range(13, n):
        atr[i] = np.mean(tr[i - 13:i + 1])
    ema20, ema50, ema100 = _ema(cl, 20), _ema(cl, 50), _ema(cl, 100)
    avg_vol = np.full(n, np.nan)
    for i in range(20, n):
        avg_vol[i] = np.mean(vol[i - 20:i])
    rsi = np.full(n, np.nan)
    delta = np.diff(cl, prepend=np.nan)
    for i in range(14, n):
        d = delta[i - 13:i + 1]
        up, down = np.maximum(d, 0).mean(), np.maximum(-d, 0).mean()
        rsi[i] = 50.0 if up == 0 and down == 0 else (100.0 if down == 0 else 100 - 100 / (1 + up / down))
    max20 = np.full(n, np.nan); min20 = np.full(n, np.nan)
    for i in range(19, n):
        max20[i] = np.max(hi[i - 19:i + 1]); min20[i] = np.min(lo[i - 19:i + 1])

    base = {
        "ret_1": cl / np.r_[np.nan, cl[:-1]] - 1,
        "ret_3": cl / np.r_[np.full(3, np.nan), cl[:-3]] - 1,
        "ret_6": cl / np.r_[np.full(6, np.nan), cl[:-6]] - 1,
        "ret_12": cl / np.r_[np.full(12, np.nan), cl[:-12]] - 1,
        "ret_24": cl / np.r_[np.full(24, np.nan), cl[:-24]] - 1,
        "ret_48": cl / np.r_[np.full(48, np.nan), cl[:-48]] - 1,
        "ema20_gap": cl / ema20 - 1, "ema50_gap": cl / ema50 - 1,
        "ema100_gap": cl / ema100 - 1, "ema20_50_gap": ema20 / ema50 - 1,
        "rsi": (rsi - 50) / 50, "atr_pct": atr / cl,
        "volume_ratio": np.minimum(np.divide(vol, avg_vol, out=np.full(n, np.nan), where=avg_vol > 0), 20.0),
        "candle_body_atr": np.divide(cl - op, atr, out=np.full(n, np.nan), where=atr > 0),
        "close_location": 2 * (cl - lo) / np.maximum(hi - lo, 1e-12) - 1,
        "range20_atr": np.divide(max20 - min20, atr, out=np.full(n, np.nan), where=atr > 0),
    }
    btc = np.asarray([btc_by_ts.get(int(t), (np.nan, np.nan, np.nan, np.nan)) for t in ts])
    base["btc_ret_1"], base["btc_ret_3"], base["btc_ret_12"], base["btc_ema20_50_gap"] = btc.T
    hour = ((ts.astype(np.int64) // 3_600_000) % 24).astype(np.float64)
    weekday = ((ts.astype(np.int64) // 86_400_000 + 3) % 7).astype(np.float64)
    base["hour_sin"] = np.sin(2 * np.pi * hour / 24)
    base["hour_cos"] = np.cos(2 * np.pi * hour / 24)
    base["weekday_sin"] = np.sin(2 * np.pi * weekday / 7)
    base["weekday_cos"] = np.cos(2 * np.pi * weekday / 7)
    return np.column_stack([base[k] for k in base]), ts.astype(np.int64)


BASE_FEATURES = ["ret_1", "ret_3", "ret_6", "ret_12", "ret_24", "ret_48", "ema20_gap", "ema50_gap", "ema100_gap", "ema20_50_gap", "rsi", "atr_pct", "volume_ratio", "candle_body_atr", "close_location", "range20_atr", "btc_ret_1", "btc_ret_3", "btc_ret_12", "btc_ema20_50_gap", "hour_sin", "hour_cos", "weekday_sin", "weekday_cos"]


def build_samples(raw: np.ndarray, btc_map: dict, symbol_code: int) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    feats, ts = feature_frame(raw, btc_map)
    _, _, hi, lo, cl, _ = raw.T
    n = len(raw) - HORIZON
    entry, atr = cl[:n], feats[:n, BASE_FEATURES.index("atr_pct")] * cl[:n]
    future_hi = np.column_stack([hi[k:k + n] for k in range(1, HORIZON + 1)])
    future_lo = np.column_stack([lo[k:k + n] for k in range(1, HORIZON + 1)])
    future_close = cl[HORIZON:HORIZON + n]
    times = ts[:n]
    x_out, y_out, ret_out, t_out, sym_out = [], [], [], [], []
    for sign in (1.0, -1.0):
        tp_level = entry + sign * TP_ATR * atr
        sl_level = entry - sign * SL_ATR * atr
        if sign > 0:
            tp_hit, sl_hit = future_hi >= tp_level[:, None], future_lo <= sl_level[:, None]
        else:
            tp_hit, sl_hit = future_lo <= tp_level[:, None], future_hi >= sl_level[:, None]
        tp_step = np.where(tp_hit.any(axis=1), tp_hit.argmax(axis=1) + 1, HORIZON + 1)
        sl_step = np.where(sl_hit.any(axis=1), sl_hit.argmax(axis=1) + 1, HORIZON + 1)
        ambiguous = (tp_step == sl_step) & (tp_step <= HORIZON)
        valid = ~ambiguous & np.isfinite(feats[:n]).all(axis=1) & (atr > 0) & (entry > 0)
        success = tp_step < sl_step
        exit_price = np.where(success, tp_level, np.where(sl_step <= HORIZON, sl_level, future_close))
        returns = sign * (exit_price / entry - 1) - ROUND_TRIP_COST
        # Convert raw feature vector into the direction-aware model inputs.
        f = {name: feats[:n, j] for j, name in enumerate(BASE_FEATURES)}
        names = ["side_sign"]
        values = [np.full(n, sign)]
        directional = {"ret_1", "ret_3", "ret_6", "ret_12", "ret_24", "ret_48", "ema20_gap", "ema50_gap", "ema100_gap", "ema20_50_gap", "rsi", "candle_body_atr", "close_location", "btc_ret_1", "btc_ret_3", "btc_ret_12", "btc_ema20_50_gap"}
        for name in BASE_FEATURES:
            if name == "side_sign":
                continue
            out_name = "side_" + name if name in directional else name
            values.append(f[name] * sign if name in directional else f[name])
            names.append(out_name)
        if names != FEATURES:
            raise RuntimeError("Python feature order mismatch")
        matrix = np.column_stack(values)
        x_out.append(matrix[valid].astype(np.float32))
        y_out.append(success[valid].astype(np.uint8))
        ret_out.append(returns[valid].astype(np.float32))
        t_out.append(times[valid])
        sym_out.append(np.full(valid.sum(), symbol_code, dtype=np.int16))
    return tuple(np.concatenate(a) for a in (x_out, y_out, ret_out, t_out, sym_out))


def split_windows(times: np.ndarray) -> dict[str, np.ndarray]:
    unique = np.unique(times)
    if len(unique) < 10_000:
        raise RuntimeError(f"Too little history: only {len(unique)} unique bars")
    # Keep calibration, threshold-selection, independent validation, and final
    # holdout periods separate. The final holdout covers the latest 10% of bars.
    a, b, c, d = (unique[int(len(unique) * q)] for q in (0.60, 0.70, 0.80, 0.90))
    gap = HORIZON * BAR_MS
    return {
        "train": times < a - gap,
        "cal": (times >= a + gap) & (times < b - gap),
        "select": (times >= b + gap) & (times < c - gap),
        "validation": (times >= c + gap) & (times < d - gap),
        "test": times >= d + gap,
    }


def rolling_fold_windows(times: np.ndarray, train_fractions=(0.50, 0.55, 0.60),
                         block_fraction=0.05) -> list[dict[str, np.ndarray]]:
    """Build expanding-window train/calibration/selection/evaluation folds.

    Each fold advances forward in time. Label horizons are embargoed between
    adjacent blocks so labels cannot reach across a split boundary. The final
    10% holdout remains separate and is never used by these diagnostic folds.
    """
    unique = np.unique(times)
    gap = HORIZON * BAR_MS
    folds = []
    for train_fraction in train_fractions:
        train_end = unique[int(len(unique) * train_fraction)]
        cal_end = unique[int(len(unique) * (train_fraction + block_fraction))]
        select_end = unique[int(len(unique) * (train_fraction + 2 * block_fraction))]
        eval_end = unique[int(len(unique) * (train_fraction + 3 * block_fraction))]
        masks = {
            "train": times < train_end - gap,
            "cal": (times >= train_end + gap) & (times < cal_end - gap),
            "select": (times >= cal_end + gap) & (times < select_end - gap),
            "evaluation": (times >= select_end + gap) & (times < eval_end - gap),
        }
        if min(int(mask.sum()) for mask in masks.values()) < 10_000:
            raise RuntimeError("A rolling evaluation fold has too few examples")
        folds.append(masks)
    return folds


def sigmoid(z):
    z = np.clip(np.asarray(z, dtype=np.float64), -40, 40)
    return 1 / (1 + np.exp(-z))


def export_tree(predictor) -> list:
    nodes = predictor.nodes
    return [[int(row["feature_idx"]), float(row["num_threshold"]), int(row["left"]), int(row["right"]), bool(row["missing_go_to_left"]), bool(row["is_leaf"]), float(row["value"])] for row in nodes]


def exported_raw(model_dict: dict, x: np.ndarray) -> np.ndarray:
    out = np.full(len(x), float(model_dict["baseline"]), dtype=np.float64)
    for tree in model_dict["trees"]:
        nodes = np.asarray(tree, dtype=object)
        feature = nodes[:, 0].astype(np.int32)
        threshold = nodes[:, 1].astype(np.float64)
        left = nodes[:, 2].astype(np.int32)
        right = nodes[:, 3].astype(np.int32)
        missing_left = nodes[:, 4].astype(bool)
        is_leaf = nodes[:, 5].astype(bool)
        value = nodes[:, 6].astype(np.float64)
        at = np.zeros(len(x), dtype=np.int32)
        active = np.ones(len(x), dtype=bool)
        while active.any():
            rows = np.flatnonzero(active)
            current = at[rows]
            leaf_mask = is_leaf[current]
            if leaf_mask.any():
                leaf_rows = rows[leaf_mask]
                # sklearn stores the learning-rate-scaled value in each leaf.
                out[leaf_rows] += value[current[leaf_mask]]
                active[leaf_rows] = False
            inner_rows = rows[~leaf_mask]
            if inner_rows.size:
                inner_nodes = at[inner_rows]
                cols = feature[inner_nodes]
                observed = x[inner_rows, cols]
                go_left = np.where(np.isfinite(observed), observed <= threshold[inner_nodes], missing_left[inner_nodes])
                at[inner_rows] = np.where(go_left, left[inner_nodes], right[inner_nodes])
    return out


def model_prob(model_dict: dict, x: np.ndarray) -> np.ndarray:
    raw = exported_raw(model_dict, x)
    cal = model_dict["calibration"]
    return sigmoid(cal["slope"] * raw + cal["intercept"])


def fit_and_export(x_train, y_train, x_cal, y_cal):
    pos = max(int(y_train.sum()), 1)
    neg = max(len(y_train) - pos, 1)
    weights = np.where(y_train == 1, len(y_train) / (2 * pos), len(y_train) / (2 * neg))
    model = HistGradientBoostingClassifier(
        loss="log_loss", learning_rate=0.06, max_iter=180, max_leaf_nodes=15,
        max_depth=5, min_samples_leaf=180, l2_regularization=4.0,
        early_stopping=False, random_state=20261013,
    )
    model.fit(x_train, y_train, sample_weight=weights)
    if len(model._predictors[0]) != 1:
        raise RuntimeError("Unexpected multiclass model shape")
    exported = {
        "baseline": float(model._baseline_prediction[0, 0]),
        "learning_rate": 1.0,
        "trees": [export_tree(stage[0]) for stage in model._predictors],
    }
    # Verify Android's JSON tree evaluator matches scikit-learn before packaging.
    check = np.linspace(0, len(x_cal) - 1, min(2000, len(x_cal)), dtype=np.int64)
    error = np.max(np.abs(exported_raw(exported, x_cal[check]) - model.decision_function(x_cal[check])))
    if error > 1e-6:
        raise RuntimeError(f"Exported tree evaluator disagrees with sklearn: {error}")
    raw_cal = model.decision_function(x_cal).reshape(-1, 1)
    calibrator = LogisticRegression(C=1.0, max_iter=1000, random_state=20261013)
    calibrator.fit(raw_cal, y_cal)
    exported["calibration"] = {"slope": float(calibrator.coef_[0, 0]), "intercept": float(calibrator.intercept_[0])}
    return exported, model


def non_overlapping(trade_rows: list[tuple[int, int, float, float]], threshold: float) -> list[tuple[int, int, float, float]]:
    # Tuple format: (timestamp, symbol_code, probability, net_return). At most
    # one active trade per symbol; the label horizon defines its exit time.
    by_symbol: dict[int, list[tuple[int, int, float, float]]] = {}
    for row in trade_rows:
        if row[2] >= threshold:
            by_symbol.setdefault(row[1], []).append(row)
    chosen = []
    for rows in by_symbol.values():
        rows.sort(key=lambda r: r[0])
        next_allowed = -1
        i = 0
        while i < len(rows):
            j = i + 1
            while j < len(rows) and rows[j][0] == rows[i][0]:
                j += 1
            # If both LONG and SHORT pass at the same candle, keep the model's
            # higher-confidence direction instead of depending on row order.
            row = max(rows[i:j], key=lambda r: r[2])
            if row[0] >= next_allowed:
                chosen.append(row)
                next_allowed = row[0] + HORIZON * BAR_MS
            i = j
    return sorted(chosen)


def portfolio_metrics(rows: list[tuple[int, int, float, float]]) -> dict:
    if not rows:
        return {"trades": 0, "win_rate": 0.0, "net_mean": -1.0, "profit_factor": 0.0, "max_drawdown": 1.0, "daily_lcb90": -1.0}
    returns = np.asarray([r[3] for r in rows], dtype=np.float64)
    pos = returns[returns > 0].sum()
    neg = -returns[returns < 0].sum()
    # Trades on different symbols can be open at the same time. Do not treat
    # them as sequential full-equity bets: allocate one equal slot per active
    # symbol and aggregate same-day PnL before updating portfolio equity.
    n_slots = max(len({r[1] for r in rows}), 1)
    day_values: dict[int, list[float]] = {}
    for row in rows:
        day_values.setdefault(row[0] // 86_400_000, []).append(row[3] / n_slots)
    daily = np.asarray([sum(v) for _, v in sorted(day_values.items())], dtype=np.float64)
    equity = np.cumprod(1 + np.clip(daily, -0.99, 10))
    running_peak = np.maximum.accumulate(np.r_[1.0, equity])[1:]
    drawdown = equity / running_peak - 1
    rng = np.random.default_rng(20261013)
    if len(daily) >= 8:
        boot = np.asarray([rng.choice(daily, size=len(daily), replace=True).mean() for _ in range(1000)])
        lcb = float(np.quantile(boot, .10))
    else:
        lcb = -1.0
    return {
        "trades": int(len(returns)),
        "win_rate": float(np.mean(returns > 0)),
        "net_mean": float(np.mean(returns)),
        "profit_factor": float(pos / neg) if neg > 0 else 99.0,
        "max_drawdown": float(abs(min(np.min(drawdown), 0.0))),
        "daily_lcb90": lcb,
    }


def trade_metrics_for_slice(prob, returns, timestamps, symbols, mask,
                            threshold: float, extra_cost: float = 0.0) -> dict:
    rows = [(int(t), int(s), float(p), float(r) - extra_cost)
            for p, r, t, s, keep in zip(prob, returns, timestamps, symbols, mask)
            if keep]
    return portfolio_metrics(non_overlapping(rows, threshold))


def segment_diagnostics(prob, returns, timestamps, symbols, sides, volatility,
                        symbol_names: list[str], threshold: float,
                        extra_cost: float = 0.0) -> dict:
    """Report independent, threshold-fixed results by direction/asset/regime."""
    result = {"by_direction": {}, "by_symbol": {}, "by_volatility_quartile": {}}
    for sign, name in ((1, "long"), (-1, "short")):
        result["by_direction"][name] = trade_metrics_for_slice(
            prob, returns, timestamps, symbols, sides == sign, threshold, extra_cost)
    for code, name in enumerate(symbol_names):
        result["by_symbol"][name] = trade_metrics_for_slice(
            prob, returns, timestamps, symbols, symbols == code, threshold, extra_cost)
    cuts = np.quantile(volatility[np.isfinite(volatility)], [0.25, 0.50, 0.75])
    bins = np.digitize(volatility, cuts)
    for idx, name in enumerate(("q1_low", "q2", "q3", "q4_high")):
        result["by_volatility_quartile"][name] = trade_metrics_for_slice(
            prob, returns, timestamps, symbols, bins == idx, threshold, extra_cost)
    return result


def cost_stress_metrics(rows, additional_costs=(0.0, 0.0008, 0.0018)) -> dict:
    """Stress test net returns after the base 12 bp cost already in labels.

    Additional 8/18 bp scenarios represent total assumed round-trip costs of
    20/30 bp. Funding is reported as a limitation until actual historical
    funding rates are joined to each simulated position.
    """
    result = {}
    for extra in additional_costs:
        stressed = [(t, s, p, r - extra) for t, s, p, r in rows]
        label = f"total_{round((ROUND_TRIP_COST + extra) * 10_000)}_bps"
        result[label] = portfolio_metrics(stressed)
    return result


def choose_threshold(prob: np.ndarray, y: np.ndarray, ret: np.ndarray, ts: np.ndarray, sym: np.ndarray) -> tuple[float, dict]:
    rows = [(int(t), int(s), float(p), float(r)) for p, t, s, r in zip(prob, ts, sym, ret)]
    candidates = []
    diagnostic = []
    # A 70% event probability is not a universal break-even threshold: the
    # TP/SL payoff is asymmetric. Search lower probability cutoffs on the
    # dedicated selection window, then require independent validation and the
    # untouched final holdout to pass.
    for threshold in np.arange(0.40, 0.901, 0.01):
        selected = non_overlapping(rows, float(threshold))
        metrics = portfolio_metrics(selected)
        if metrics["trades"] >= 120:
            diagnostic.append((metrics["net_mean"], float(threshold), metrics))
        if metrics["trades"] >= 120 and metrics["net_mean"] > 0 and metrics["daily_lcb90"] > 0:
            score = metrics["net_mean"] * math.sqrt(metrics["trades"])
            candidates.append((score, float(threshold), metrics))
    if candidates:
        _, threshold, metrics = max(candidates, key=lambda row: row[0])
        metrics = {**metrics, "selection_gate_passed": True}
        return threshold, metrics
    if diagnostic:
        # Keep the best observed selection-window result for honest reporting;
        # the separate validation and holdout gates still prevent promotion.
        _, threshold, metrics = max(diagnostic, key=lambda row: (row[0], row[2]["trades"]))
        metrics = {**metrics, "selection_gate_passed": False}
        return threshold, metrics
    metrics = {**portfolio_metrics([]), "selection_gate_passed": False}
    return 0.70, metrics


def model_from_fitted(exported: dict, feature_names=FEATURES, threshold=0.70) -> dict:
    out = {
        "schema_version": 2, "model_type": "hist_gradient_boosting_binary",
        "eligible": True, "feature_names": feature_names, "baseline": exported["baseline"],
        "learning_rate": exported["learning_rate"], "calibration": exported["calibration"],
        "threshold": threshold, "trees": exported["trees"],
    }
    canonical = json.dumps(out, sort_keys=True, separators=(",", ":")).encode()
    out["model_id"] = hashlib.sha256(canonical).hexdigest()[:20]
    out["trained_at_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
    return out


def load_model(path: Path):
    if not path.exists():
        return None
    try:
        obj = json.loads(path.read_text())
        if obj.get("schema_version") != 2 or not obj.get("eligible"):
            return None
        return obj
    except (OSError, json.JSONDecodeError):
        return None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--days", type=int, default=730)
    parser.add_argument("--symbols", type=int, default=24)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--champion", type=Path, default=Path("models/latest.json"))
    parser.add_argument("--report", type=Path, default=Path("model_report.json"))
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    champion = load_model(args.champion)
    report: dict = {
        "status": "failed", "reason": "training did not finish", "interval": INTERVAL,
        "horizon_bars": HORIZON, "tp_atr": TP_ATR, "sl_atr": SL_ATR,
        "round_trip_cost_assumption": ROUND_TRIP_COST,
        "universe_method": "fixed list of established Binance USDT perpetuals from official public archives; survivorship bias is possible",
        "data_source": "Binance public data archives (data.binance.vision), USD-M futures 15m klines",
        "split_method": "chronological 60/70/80/90 percent cutoffs: train/calibration/threshold selection/independent validation/final holdout, with a 12-bar label embargo",
    }
    try:
        now = int(time.time() * 1000)
        end = now - now % BAR_MS - 1
        start = end - args.days * 86_400_000
        symbols = select_symbols(max(4, args.symbols))
        if "BTCUSDT" not in symbols:
            symbols.insert(0, "BTCUSDT")
        report["symbols"] = symbols
        raw_data: dict[str, np.ndarray] = {}
        for idx, symbol in enumerate(symbols):
            print(f"Downloading {idx + 1}/{len(symbols)} {symbol}", flush=True)
            raw = fetch_klines(symbol, start, end)
            if len(raw) >= 10_000:
                raw_data[symbol] = raw
        if "BTCUSDT" not in raw_data or len(raw_data) < 4:
            raise RuntimeError("Insufficient historical symbols/data from Binance")
        btc_raw = raw_data["BTCUSDT"]
        btc_feats, btc_ts = feature_frame(btc_raw, {})
        # BTC context values are based only on BTC candles closed at the same time.
        btc_map = {}
        for i, t in enumerate(btc_ts):
            if i >= 12:
                btc_map[int(t)] = (float(btc_feats[i, 0]), float(btc_feats[i, 1]), float(btc_feats[i, 3]), float(btc_feats[i, 9]))
        all_arrays = [[], [], [], [], []]
        used = []
        for code, (symbol, raw) in enumerate(raw_data.items()):
            arrs = build_samples(raw, btc_map, code)
            for out, arr in zip(all_arrays, arrs):
                out.append(arr)
            used.append(symbol)
        if len(used) < 4:
            raise RuntimeError("Fewer than four training symbols had sufficient data")
        x, y, rets, ts, sym = (np.concatenate(v) for v in all_arrays)
        good = np.isfinite(x).all(axis=1) & np.isfinite(rets)
        x, y, rets, ts, sym = x[good], y[good], rets[good], ts[good], sym[good]
        windows = split_windows(ts)
        if min(int(windows[k].sum()) for k in ("train", "cal", "select", "validation", "test")) < 10_000:
            raise RuntimeError("A chronological training/evaluation window has too few examples")
        x_train, y_train = x[windows["train"]], y[windows["train"]]
        x_cal, y_cal = x[windows["cal"]], y[windows["cal"]]
        x_sel, y_sel, ret_sel, ts_sel, sym_sel = x[windows["select"]], y[windows["select"]], rets[windows["select"]], ts[windows["select"]], sym[windows["select"]]
        x_val, y_val, ret_val, ts_val, sym_val = x[windows["validation"]], y[windows["validation"]], rets[windows["validation"]], ts[windows["validation"]], sym[windows["validation"]]
        x_test, y_test, ret_test, ts_test, sym_test = x[windows["test"]], y[windows["test"]], rets[windows["test"]], ts[windows["test"]], sym[windows["test"]]
        report.update({"data_start_utc": dt.datetime.fromtimestamp(start / 1000, dt.timezone.utc).isoformat(), "data_end_utc": dt.datetime.fromtimestamp(end / 1000, dt.timezone.utc).isoformat(), "symbols_used": used, "samples": int(len(y)), "positive_label_rate": float(y.mean()), "window_samples": {k: int(v.sum()) for k, v in windows.items()}})

        # Refit on three expanding chronological folds. The final 10% holdout
        # below is left untouched and remains the ultimate promotion check.
        rolling_results = []
        for fold_index, fold in enumerate(rolling_fold_windows(ts), start=1):
            print(f"Training rolling evaluation fold {fold_index}/3", flush=True)
            fold_exported, _ = fit_and_export(
                x[fold["train"]], y[fold["train"]],
                x[fold["cal"]], y[fold["cal"]])
            fold_select_prob = model_prob(fold_exported, x[fold["select"]])
            fold_threshold, fold_selection = choose_threshold(
                fold_select_prob, y[fold["select"]], rets[fold["select"]],
                ts[fold["select"]], sym[fold["select"]])
            fold_eval_prob = model_prob(fold_exported, x[fold["evaluation"]])
            fold_metrics = trade_metrics_for_slice(
                fold_eval_prob, rets[fold["evaluation"]], ts[fold["evaluation"]],
                sym[fold["evaluation"]], np.ones(int(fold["evaluation"].sum()), dtype=bool),
                fold_threshold)
            fold_rows = non_overlapping(
                [(int(t), int(s), float(p), float(r)) for p, t, s, r in zip(
                    fold_eval_prob, ts[fold["evaluation"]], sym[fold["evaluation"]],
                    rets[fold["evaluation"]])], fold_threshold)
            rolling_results.append({
                "fold": fold_index,
                "selected_threshold": fold_threshold,
                "selection_gate_passed": bool(fold_selection.get("selection_gate_passed")),
                "evaluation": fold_metrics,
                "cost_stress": cost_stress_metrics(fold_rows),
            })
        fold_means = [row["cost_stress"]["total_20_bps"]["net_mean"] for row in rolling_results]
        rolling_gate = (sum(row["evaluation"]["trades"] >= 60 and
                            row["cost_stress"]["total_20_bps"]["net_mean"] > 0 and
                            row["cost_stress"]["total_20_bps"]["daily_lcb90"] > 0
                            for row in rolling_results) >= 2
                        and float(np.mean(fold_means)) > 0)
        report["rolling_walk_forward"] = {
            "method": "3 expanding chronological folds; each has distinct train/calibration/threshold/evaluation blocks with 12-bar embargo",
            "folds": rolling_results,
            "profitable_folds_at_20bps": int(sum(
                row["cost_stress"]["total_20_bps"]["net_mean"] > 0
                for row in rolling_results)),
            "mean_net_return_at_20bps": float(np.mean(fold_means)),
            "gate_passed": bool(rolling_gate),
        }

        exported, fitted = fit_and_export(x_train, y_train, x_cal, y_cal)
        p_sel = model_prob({**exported, "threshold": .7}, x_sel)
        threshold, select_metrics = choose_threshold(p_sel, y_sel, ret_sel, ts_sel, sym_sel)
        p_val = model_prob({**exported, "threshold": threshold}, x_val)
        val_rows = [(int(t), int(s), float(p), float(r)) for p, t, s, r in zip(p_val, ts_val, sym_val, ret_val)]
        val_metrics = portfolio_metrics(non_overlapping(val_rows, threshold))
        selected_validation = non_overlapping(val_rows, threshold)
        validation_cost_stress = cost_stress_metrics(selected_validation)
        p_test = model_prob({**exported, "threshold": threshold}, x_test)
        test_rows = [(int(t), int(s), float(p), float(r)) for p, t, s, r in zip(p_test, ts_test, sym_test, ret_test)]
        selected_test = non_overlapping(test_rows, threshold)
        metrics = portfolio_metrics(selected_test)
        report["test_diagnostics"] = segment_diagnostics(
            p_test, ret_test, ts_test, sym_test,
            x_test[:, FEATURES.index("side_sign")].astype(np.int8),
            x_test[:, FEATURES.index("atr_pct")], used, threshold)
        report["cost_stress"] = {
            "note": "Base return includes 12 bps round-trip cost; additional stress is applied below. Historical funding is not yet joined and must be added before deployment.",
            "validation": validation_cost_stress,
            **cost_stress_metrics(selected_test),
        }
        test_prob = p_test
        brier = float(brier_score_loss(y_test, test_prob))
        base_brier = float(brier_score_loss(y_test, np.full(len(y_test), y_train.mean())))
        ll = float(log_loss(y_test, np.clip(test_prob, 1e-6, 1 - 1e-6)))
        auc = float(roc_auc_score(y_test, test_prob)) if len(np.unique(y_test)) == 2 else 0.5
        report["threshold_selection"] = {**select_metrics, "selected_threshold": threshold}
        report["validation"] = {**val_metrics, "selected_threshold": threshold}
        report["out_of_sample"] = {**metrics, "brier": brier, "base_brier": base_brier, "brier_skill": 1 - brier / max(base_brier, 1e-12), "log_loss": ll, "auc": auc}
        # A model is promoted only when its unseen future period has enough
        # independent, non-overlapping observations and positive conservative
        # net expectancy after the declared fee/slippage assumption.
        validation_ok = (val_metrics.get("trades", 0) >= 120
                         and val_metrics.get("net_mean", -1) > 0
                         and val_metrics.get("daily_lcb90", -1) > 0)
        cost_20 = report["cost_stress"]["total_20_bps"]
        promotion_gates = {
            "threshold_selection": bool(select_metrics.get("selection_gate_passed", False)),
            "independent_validation": bool(validation_ok),
            "validation_20bp_cost_stress": bool(
                validation_cost_stress["total_20_bps"]["net_mean"] > 0 and
                validation_cost_stress["total_20_bps"]["daily_lcb90"] > 0),
            "rolling_walk_forward": bool(rolling_gate),
            "holdout_minimum_trades": bool(metrics["trades"] >= 200),
            "holdout_positive_net_expectancy": bool(metrics["net_mean"] > 0),
            "holdout_positive_daily_confidence_bound": bool(metrics["daily_lcb90"] > 0),
            "holdout_max_drawdown": bool(metrics["max_drawdown"] <= 0.25),
            "20bp_cost_stress_expectancy": bool(cost_20["net_mean"] > 0),
            "20bp_cost_stress_confidence_bound": bool(cost_20["daily_lcb90"] > 0),
            "brier_skill": bool(brier < base_brier),
            "auc": bool(auc >= 0.52),
        }
        report["promotion_gates"] = promotion_gates
        report["failed_promotion_gates"] = [name for name, passed in promotion_gates.items() if not passed]
        passes = all(promotion_gates.values())
        if champion is not None:
            old_p = model_prob(champion, x_test)
            old_rows = [(int(t), int(s), float(p), float(r)) for p, t, s, r in zip(old_p, ts_test, sym_test, ret_test)]
            old_metrics = portfolio_metrics(non_overlapping(old_rows, float(champion.get("threshold", .7))))
            report["champion_on_same_holdout"] = old_metrics
            passes = passes and metrics["net_mean"] > old_metrics["net_mean"] + 0.00005 and metrics["daily_lcb90"] >= old_metrics["daily_lcb90"]
        report["candidate_passed"] = bool(passes)
        report["validation_gate_passed"] = bool(validation_ok)
        if passes:
            model_dict = model_from_fitted(exported, threshold=threshold)
            model_dict["metrics"] = report["out_of_sample"]
            model_dict["symbols"] = used
            model_dict["training_days"] = args.days
            model_dict["training_data_end_utc"] = report["data_end_utc"]
            args.output.write_text(json.dumps(model_dict, separators=(",", ":")))
            report["status"] = "promoted"
            report["model_id"] = model_dict["model_id"]
            report["reason"] = "passed chronological holdout quality gates"
        elif champion is not None:
            args.output.write_text(json.dumps(champion, separators=(",", ":")))
            report["status"] = "kept_champion"
            report["reason"] = "candidate failed; previous champion retained"
        else:
            model_dict = model_from_fitted(exported, threshold=threshold)
            model_dict["eligible"] = False
            model_dict["metrics"] = report["out_of_sample"]
            model_dict["symbols"] = used
            model_dict["training_days"] = args.days
            model_dict["training_data_end_utc"] = report["data_end_utc"]
            args.output.write_text(json.dumps(model_dict, separators=(",", ":")))
            report["status"] = "rejected_no_champion"
            report["reason"] = "candidate failed; no model will be labeled validated"
        # Candidate and baseline test summary is also saved as a CI artifact.
        report["created_at_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
        args.report.write_text(json.dumps(report, indent=2))
        print(json.dumps(report, indent=2), flush=True)
        return 0 if passes or champion is not None else 2
    except Exception as exc:
        report["reason"] = f"{type(exc).__name__}: {exc}"
        report["created_at_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
        if champion is not None:
            args.output.write_text(json.dumps(champion, separators=(",", ":")))
            report["status"] = "kept_champion_after_training_error"
            report["candidate_passed"] = False
            args.report.write_text(json.dumps(report, indent=2))
            print(json.dumps(report, indent=2), file=sys.stderr, flush=True)
            return 0
        args.report.write_text(json.dumps(report, indent=2))
        print(json.dumps(report, indent=2), file=sys.stderr, flush=True)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
