# QuantDesk AI Android 0.5

This project contains an Android market scanner and a separate model-training pipeline. GitHub Actions downloads Binance USDⓈ-M perpetual 15-minute candles from Binance's official public archive, trains a gradient-boosted tree classifier, calibrates probabilities, selects a decision threshold on a later period, then checks it on a final unseen chronological period. The fixed training universe contains up to 24 USDT perpetuals; symbols without enough archive history are skipped. The phone scans only symbols declared in the model artifact, preventing an untested 24-symbol model from being applied to hundreds of unrelated contracts.

## What must pass before an APK is built

The primary chronological split reserves separate periods for training (first 60%), probability calibration (60–70%), threshold selection (70–80%), independent validation (80–90%), and final holdout (last 10%), with a 12-bar label embargo between windows. The pipeline also runs three expanding-window walk-forward evaluations before the untouched final holdout. Reports break results down by long/short, symbol, and volatility quartile, and include 12/20/30-basis-point round-trip cost scenarios. The 12-basis-point base cost is already deducted from labels; extra stress costs are applied to selected trades. Historical funding rates are not yet included and remain a deployment limitation.

A candidate must pass threshold selection, independent validation, the rolling evaluations, the final holdout, and the 20-basis-point cost stress. It also needs enough non-overlapping observations, positive confidence bounds, a bounded drawdown, better holdout Brier score than the training-prevalence baseline, and AUC of at least 0.52. When an existing champion is available, a new candidate must also beat it on the same holdout. If checks fail and no champion exists, the workflow still produces an installable APK shell, but the app refuses to produce AI predictions until a model passes validation. The `model_report.json` artifact identifies failed gates and provides per-segment results.

The tests in `ml/test_model.py` cover feature creation, chronological embargoes, rolling-fold ordering, cost stress, segment diagnostics, model export parity, and threshold selection. Passing these code tests does not establish trading performance; only the market-data evaluation report can do that.

## Ongoing updates

The workflow runs on a daily schedule and when the source ZIP changes. It only replaces `models/latest.json` when a candidate passes the gates; otherwise it retains the existing validated model. The Android app checks that file every six hours and retains its cached model if an update cannot be downloaded.

The app stores its own shadow outcomes on the phone. It does not upload those private records. Daily training uses public candle history and derives TP/SL labels from it, so phone-specific outcomes are not currently fed into training. While scanning is running, the app fetches recent crypto headlines from GDELT and macro/regulatory releases from the Federal Reserve and SEC RSS feeds. It displays source, publication time when available, title, and link. These headlines are research context only: they are not sentiment-scored and do not alter the model's TP probability. GDELT's recent-news search does not provide the aligned multi-year historical dataset needed to train and validate news features in this pipeline.

## Assumptions and limits

- Signals use closed 15-minute candles and a 12-candle (three-hour) TP-before-SL horizon.
- The backtest uses 1.35 ATR for TP1, 1.15 ATR for the stop, and a 0.12% round-trip cost assumption. Funding and sudden slippage beyond that assumption are not modeled.
- A fixed list of established contracts defines the training universe; historical survivorship bias is possible, and this is not a dynamic top-volume ranking.
- The holdout is chronological, but it is still a historical simulation. It cannot guarantee future accuracy, profitability, or protection from losses.
- The headline panel is a source feed, not an AI news analyst. A reliable news-based model needs time-aligned historical headlines, source quality controls, event de-duplication, and its own out-of-sample tests before headlines can change a prediction.
- The app only displays analysis candidates. It does not place orders.

## Build

The repository workflow expects `QuantDesk-AI-Android-ML-v0.5.1.zip` at the repository root. It tests and trains the model before building `app-debug.apk`. The APK is available as a GitHub Actions artifact even when no eligible model is present; in that case it installs in a no-prediction state and clearly reports that validation is pending. If archive data is blocked or the candidate fails any promotion gate, the training report artifact includes the reason.
