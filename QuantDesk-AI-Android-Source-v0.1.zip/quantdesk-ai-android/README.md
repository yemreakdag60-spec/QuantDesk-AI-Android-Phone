# QuantDesk AI Android — 0.1.0

This is a separate Android application. It does not overwrite or update the user's other QuantDesk app. The scanner and learning model run on the phone and use public Binance USDⓈ-M Futures data; no exchange key or trading permission is requested.

## Current behavior

- Scans up to 250 of the highest-volume USDT perpetual contracts with at least 10 million USDT in 24-hour quote volume.
- Uses closed 15-minute candles, BTC context, ATR-based TP1/stop references, and a distinct technical setup score.
- Records qualified setups in local shadow history before the model is trained. It records TP1, SL, time exit, or same-candle ambiguity.
- Trains locally once there are at least 200 labeled outcomes, with chronological train/validation data and quality gates. No model probability is shown before a model passes those gates. After training, only estimates at or above 70% are displayed.
- Stores records and the champion/rollback model in private app storage. No real order is sent.

## Install/build

An Android SDK is not available in the Codex build environment, so this source package includes a GitHub Actions workflow instead of a prebuilt APK.

1. Create a new GitHub repository for this separate app.
2. Upload the contents of this project to the repository root, including `.github/workflows/build-apk.yml`.
3. Open **Actions → Build QuantDesk AI Android APK → Run workflow**.
4. Download the `QuantDesk-AI-Android-0.1.0` artifact from the completed run, extract it, and install `app-debug.apk` on the phone.

The debug APK is for personal testing. A source change or CI run may produce a different debug signing key and therefore may require uninstalling an earlier debug build before installing the next one.

## Running

Open QuantDesk AI and tap **TARAMAYI BAŞLAT**. Keep the app visible while it scans; tapping **DURDUR** stops the loop. Learned records stay on the phone if the app is closed. Binance access errors are shown as errors; the app does not fabricate prices.

## Limits of this first phone version

- Android does not guarantee nonstop background execution. This build intentionally scans while the app is visible. Android's current background execution rules restrict long-running work, and newer Android versions impose time limits on some foreground service types. A phone-only 24/7 scanner cannot be promised.
- The first installed build is untrained. It first collects shadow outcomes; validation may reject models, and the 200-record minimum is only a starting threshold, not proof of predictive quality.
- This version polls public REST endpoints every minute; it does not use WebSocket. Binance regional/network restrictions can prevent market data access.
- The app is a separate standalone Android program and is not yet connected to the existing Prism app or the Python engine.
