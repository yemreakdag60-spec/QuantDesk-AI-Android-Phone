package com.emreakdag.quantdesk.ai;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

final class AiEngine {
    static final class Candle {
        final long ts; final double open,high,low,close,volume;
        Candle(long t,double o,double h,double l,double c,double v){ts=t;open=o;high=h;low=l;close=c;volume=v;}
    }
    static final class Candidate {
        final String symbol,side; final long ts; final double entry,tp1,stop,setup,probability; final Map<String,Double> features;
        Candidate(String s,String d,long t,double e,double target,double sl,double score,double p,Map<String,Double> f){symbol=s;side=d;ts=t;entry=e;tp1=target;stop=sl;setup=score;probability=p;features=f;}
    }
    static final class Model {
        final String id; final String[] names; final double[] means,scales,weights; final double bias,brier;
        Model(String i,String[] n,double[] m,double[] s,double[] w,double b,double br){id=i;names=n;means=m;scales=s;weights=w;bias=b;brier=br;}
        double predict(Map<String,Double> f){double z=bias;for(int i=0;i<names.length;i++){Double v=f.get(names[i]);if(v==null||!Double.isFinite(v))return -1;z+=weights[i]*(v-means[i])/scales[i];}return sigmoid(z);}
    }
    static Candidate analyze(String symbol,List<Candle> c,List<Candle> btc,Model model){
        if(c.size()<60)return null;
        Map<String,Double> f=features(c,btc);if(f==null)return null;
        double longScore=setup(f,"LONG"),shortScore=setup(f,"SHORT");String side=longScore>=shortScore?"LONG":"SHORT";double score=Math.max(longScore,shortScore);
        if(score<0.64)return null;
        f.put("side_sign",side.equals("LONG")?1.0:-1.0);
        double entry=c.get(c.size()-1).close,atr=entry*f.get("atr_pct");if(atr<=0)return null;
        double stop=side.equals("LONG")?entry-1.15*atr:entry+1.15*atr;
        double tp=side.equals("LONG")?entry+1.35*atr:entry-1.35*atr;
        double p=model==null?-1:model.predict(f);
        return new Candidate(symbol,side,c.get(c.size()-1).ts,entry,tp,stop,score,p,f);
    }
    static Map<String,Double> features(List<Candle> c,List<Candle> btc){
        int n=c.size();double last=c.get(n-1).close;
        double[] closes=new double[n],high=new double[n],low=new double[n],vol=new double[n];
        for(int i=0;i<n;i++){Candle x=c.get(i);closes[i]=x.close;high[i]=x.high;low[i]=x.low;vol[i]=x.volume;}
        double e20=ema(closes,20),e50=ema(closes,50),atr=0;
        for(int i=n-14;i<n;i++)atr+=Math.max(high[i]-low[i],Math.max(Math.abs(high[i]-closes[i-1]),Math.abs(low[i]-closes[i-1])));
        atr/=14;double avgVol=0;for(int i=n-21;i<n-1;i++)avgVol+=vol[i];avgVol/=20;
        double min=low[n-20],max=high[n-20];for(int i=n-19;i<n;i++){min=Math.min(min,low[i]);max=Math.max(max,high[i]);}
        Map<String,Double> f=new TreeMap<>();
        f.put("ret_1",last/closes[n-2]-1);f.put("ret_3",last/closes[n-4]-1);f.put("ret_5",last/closes[n-6]-1);f.put("ret_12",last/closes[n-13]-1);
        f.put("ema20_gap",last/e20-1);f.put("ema50_gap",last/e50-1);f.put("ema20_50_gap",e20/e50-1);
        f.put("rsi_14",rsi(closes));f.put("atr_pct",atr/last);f.put("volume_ratio",avgVol==0?0:vol[n-1]/avgVol);
        f.put("candle_body_atr",atr==0?0:(last-c.get(n-1).open)/atr);f.put("close_location",(last-low[n-1])/Math.max(1e-12,high[n-1]-low[n-1]));
        f.put("range_20_atr",atr==0?0:(max-min)/atr);
        if(btc!=null&&btc.size()>=60){double[] bc=new double[btc.size()];for(int i=0;i<bc.length;i++)bc[i]=btc.get(i).close;int k=bc.length-1;
            f.put("btc_ret_5",bc[k]/bc[k-5]-1);f.put("btc_ret_12",bc[k]/bc[k-12]-1);f.put("btc_ema20_50_gap",ema(bc,20)/ema(bc,50)-1);
        }else{f.put("btc_ret_5",0.0);f.put("btc_ret_12",0.0);f.put("btc_ema20_50_gap",0.0);}
        return f;
    }
    private static double setup(Map<String,Double> f,String side){double s=side.equals("LONG")?1:-1,rsi=f.get("rsi_14");
        double trend=clamp(.5+s*(.45*f.get("ema20_50_gap" )+.25*f.get("ema50_gap")+.30*f.get("ret_5"))*35);
        double mom=clamp(.5+s*(.55*f.get("ret_1")+.45*f.get("ret_3"))*55);
        double fit=side.equals("LONG")?clamp((rsi-42)/24):clamp((58-rsi)/24);
        double btc=clamp(.5+s*(.45*f.get("btc_ret_5")+.35*f.get("btc_ret_12")+.20*f.get("btc_ema20_50_gap"))*25);
        double volume=clamp(f.get("volume_ratio")/2);
        return .35*trend+.25*mom+.20*fit+.10*btc+.10*volume;
    }
    static double ema(double[] v,int p){double a=2.0/(p+1),x=0;for(int i=0;i<p;i++)x+=v[i];x/=p;for(int i=p;i<v.length;i++)x=a*v[i]+(1-a)*x;return x;}
    static double rsi(double[] v){double up=0,dn=0;for(int i=v.length-14;i<v.length;i++){double d=v[i]-v[i-1];up+=Math.max(0,d);dn+=Math.max(0,-d);}up/=14;dn/=14;return dn==0?(up==0?50:100):100-100/(1+up/dn);}
    static double sigmoid(double x){if(x>=0){double z=Math.exp(-Math.min(x,40));return 1/(1+z);}double z=Math.exp(Math.max(x,-40));return z/(1+z);}
    static double clamp(double x){return Math.max(0,Math.min(1,x));}
}
