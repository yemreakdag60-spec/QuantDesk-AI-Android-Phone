package com.emreakdag.quantdesk.ai;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

final class LearningStore {
    private final SharedPreferences prefs;
    LearningStore(Context c){prefs=c.getSharedPreferences("quantdesk_ai_private",Context.MODE_PRIVATE);}

    synchronized AiEngine.Model loadModel(){try{return parseModel(new JSONObject(prefs.getString("champion","")));}catch(Exception e){try{return parseModel(new JSONObject(prefs.getString("champion_backup","")));}catch(Exception ignored){return null;}}}
    synchronized int labeledCount(){try{JSONArray a=new JSONArray(prefs.getString("records","[]"));int n=0;for(int i=0;i<a.length();i++){String o=a.getJSONObject(i).optString("outcome");if(o.equals("TP1")||o.equals("SL")||o.equals("TIME_EXIT"))n++;}return n;}catch(Exception e){return 0;}}

    synchronized void recordCandidate(AiEngine.Candidate c){try{JSONArray a=new JSONArray(prefs.getString("records","[]"));for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);if(x.optString("symbol").equals(c.symbol)&&x.optLong("ts")==c.ts&&x.optString("side").equals(c.side))return;}
        JSONObject o=new JSONObject();o.put("symbol",c.symbol);o.put("side",c.side);o.put("ts",c.ts);o.put("entry",c.entry);o.put("tp1",c.tp1);o.put("stop",c.stop);o.put("horizon",12);o.put("outcome","PENDING");o.put("features",mapJson(c.features));
        a.put(o);while(a.length()>5000){JSONArray b=new JSONArray();for(int i=a.length()-5000;i<a.length();i++)b.put(a.get(i));a=b;}
        prefs.edit().putString("records",a.toString()).apply();
    }catch(Exception ignored){}}

    synchronized void observe(String symbol,List<AiEngine.Candle> candles){try{JSONArray a=new JSONArray(prefs.getString("records","[]"));boolean changed=false;
        for(int i=0;i<a.length();i++){JSONObject s=a.getJSONObject(i);if(!s.optString("symbol").equals(symbol)||!s.optString("outcome").equals("PENDING"))continue;
            String side=s.optString("side");double tp=s.getDouble("tp1"),stop=s.getDouble("stop");long ts=s.getLong("ts");int seen=0;String result="PENDING";
            for(AiEngine.Candle c:candles){if(c.ts<=ts)continue;if(seen>=s.optInt("horizon",12))break;seen++;
                boolean th=side.equals("LONG")?c.high>=tp:c.low<=tp;boolean sh=side.equals("LONG")?c.low<=stop:c.high>=stop;
                if(th&&sh){result="AMBIGUOUS";break;}if(th){result="TP1";break;}if(sh){result="SL";break;}if(seen>=s.optInt("horizon",12))result="TIME_EXIT";
            }
            if(!result.equals("PENDING")){s.put("outcome",result);s.put("labeledAt",System.currentTimeMillis());changed=true;}
        }
        if(changed)prefs.edit().putString("records",a.toString()).apply();
    }catch(Exception ignored){}}

    synchronized void trainIfDue(){long last=prefs.getLong("last_train",0);if(System.currentTimeMillis()-last<86_400_000L)return;
        try{List<JSONObject> rows=new ArrayList<>();JSONArray a=new JSONArray(prefs.getString("records","[]"));for(int i=0;i<a.length();i++){JSONObject r=a.getJSONObject(i);String label=r.optString("outcome");if(label.equals("TP1")||label.equals("SL")||label.equals("TIME_EXIT"))rows.add(r);}
            rows.sort(Comparator.comparingLong((JSONObject r)->r.optLong("ts")));if(rows.size()<200)return;
            prefs.edit().putLong("last_train",System.currentTimeMillis()).apply();
            int split=(int)(rows.size()*.8);if(split<100||rows.size()-split<60)return;
            List<JSONObject> train=rows.subList(0,split),valid=rows.subList(split,rows.size());int[] yt=labels(train),yv=labels(valid);
            if(countClass(yt,1)<30||countClass(yt,0)<30||countClass(yv,1)<30||countClass(yv,0)<30)return;
            String[] names=featureNames(train.get(0).getJSONObject("features"));for(JSONObject r:rows)if(!same(names,featureNames(r.getJSONObject("features"))))return;
            double[][] x=matrix(train,names);double[][] vx=matrix(valid,names);Fit fit=fit(x,yt,names);double[] prob=predict(fit,vx);double prevalence=countClass(yt,1)/(double)yt.length;
            double score=brier(prob,yv),base=brier(fill(yv.length,prevalence),yv);if(score>base*.98||logloss(prob,yv)>logloss(fill(yv.length,prevalence),yv))return;
            AiEngine.Model old=loadModel();if(old!=null&&score>old.brier*.98)return;
            JSONObject saved=new JSONObject();saved.put("id",sha256(rows.toString()));saved.put("names",new JSONArray(names));saved.put("means",array(fit.means));saved.put("scales",array(fit.scales));saved.put("weights",array(fit.weights));saved.put("bias",fit.bias);saved.put("brier",score);saved.put("trainedAt",System.currentTimeMillis());
            String existing=prefs.getString("champion","");SharedPreferences.Editor edit=prefs.edit();if(!existing.isEmpty())edit.putString("champion_backup",existing);edit.putString("champion",saved.toString()).apply();
        }catch(Exception ignored){}
    }

    private static final class Fit{double[] means,scales,weights;double bias;Fit(double[]m,double[]s,double[]w,double b){means=m;scales=s;weights=w;bias=b;}}
    private static Fit fit(double[][] x,int[] y,String[] names){int n=x.length,d=names.length;double[]m=new double[d],s=new double[d],w=new double[d];for(double[]r:x)for(int j=0;j<d;j++)m[j]+=r[j]/n;for(double[]r:x)for(int j=0;j<d;j++)s[j]+=(r[j]-m[j])*(r[j]-m[j])/n;for(int j=0;j<d;j++){s[j]=Math.sqrt(s[j]);if(s[j]<1e-9)s[j]=1;}
        int pos=countClass(y,1);double prevalence=Math.max(.01,Math.min(.99,pos/(double)n));double b=Math.log(prevalence/(1-prevalence));
        for(int epoch=0;epoch<700;epoch++){double[]g=new double[d];double gb=0;for(int i=0;i<n;i++){double z=b;for(int j=0;j<d;j++)z+=w[j]*(x[i][j]-m[j])/s[j];double err=AiEngine.sigmoid(z)-y[i];gb+=err;for(int j=0;j<d;j++)g[j]+=err*(x[i][j]-m[j])/s[j];}double rate=.035/Math.sqrt(1+epoch/100.0);b-=rate*gb/n;for(int j=0;j<d;j++)w[j]-=rate*(g[j]/n+.01*w[j]);}
        return new Fit(m,s,w,b);}
    private static double[] predict(Fit f,double[][]x){double[]p=new double[x.length];for(int i=0;i<x.length;i++){double z=f.bias;for(int j=0;j<f.weights.length;j++)z+=f.weights[j]*(x[i][j]-f.means[j])/f.scales[j];p[i]=AiEngine.sigmoid(z);}return p;}
    private static double[][] matrix(List<JSONObject> rows,String[] names)throws Exception{double[][]x=new double[rows.size()][names.length];for(int i=0;i<rows.size();i++){JSONObject f=rows.get(i).getJSONObject("features");for(int j=0;j<names.length;j++)x[i][j]=f.getDouble(names[j]);}return x;}
    private static int[] labels(List<JSONObject> rows){int[]y=new int[rows.size()];for(int i=0;i<y.length;i++)y[i]=rows.get(i).optString("outcome").equals("TP1")?1:0;return y;}
    private static int countClass(int[]y,int v){int n=0;for(int x:y)if(x==v)n++;return n;}
    private static String[] featureNames(JSONObject f){List<String>n=new ArrayList<>();for(java.util.Iterator<String>it=f.keys();it.hasNext();)n.add(it.next());Collections.sort(n);return n.toArray(new String[0]);}
    private static boolean same(String[]a,String[]b){return java.util.Arrays.equals(a,b);}
    private static double brier(double[]p,int[]y){double s=0;for(int i=0;i<y.length;i++)s+=(p[i]-y[i])*(p[i]-y[i]);return s/y.length;}
    private static double logloss(double[]p,int[]y){double s=0;for(int i=0;i<y.length;i++){double q=Math.max(1e-12,Math.min(1-1e-12,p[i]));s+=-y[i]*Math.log(q)-(1-y[i])*Math.log(1-q);}return s/y.length;}
    private static double[]fill(int n,double v){double[]a=new double[n];java.util.Arrays.fill(a,v);return a;}
    private static JSONArray array(double[]x){JSONArray a=new JSONArray();for(double v:x)a.put(v);return a;}
    private static JSONObject mapJson(Map<String,Double>m)throws Exception{JSONObject o=new JSONObject();for(Map.Entry<String,Double>e:new TreeMap<>(m).entrySet())o.put(e.getKey(),e.getValue());return o;}
    private static AiEngine.Model parseModel(JSONObject o)throws Exception{if(o.length()==0)return null;String[]n=new String[o.getJSONArray("names").length()];double[]m=new double[n.length],s=new double[n.length],w=new double[n.length];for(int i=0;i<n.length;i++){n[i]=o.getJSONArray("names").getString(i);m[i]=o.getJSONArray("means").getDouble(i);s[i]=o.getJSONArray("scales").getDouble(i);w[i]=o.getJSONArray("weights").getDouble(i);if(!Double.isFinite(s[i])||s[i]<=0)return null;}return new AiEngine.Model(o.optString("id"),n,m,s,w,o.getDouble("bias"),o.getDouble("brier"));}
    private static String sha256(String s){try{byte[]b=MessageDigest.getInstance("SHA-256").digest(s.getBytes("UTF-8"));StringBuilder x=new StringBuilder();for(byte v:b)x.append(String.format(Locale.US,"%02x",v));return x.toString();}catch(Exception e){return Long.toHexString(System.nanoTime());}}
}
