package com.emreakdag.quantdesk.prism;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.TimeZone;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeMap;

/** Runtime feature calculation and compact exported gradient-boosted model inference. */
final class AiEngine {
    static final class Candle {
        final long ts;
        final double open, high, low, close, volume;
        Candle(long t, double o, double h, double l, double c, double v) {
            ts=t; open=o; high=h; low=l; close=c; volume=v;
        }
    }

    static final class Candidate {
        final String symbol, side;
        final long ts;
        final double entry, tp1, stop, setup, probability;
        final Map<String, Double> features;
        Candidate(String s, String d, long t, double e, double target, double sl,
                  double score, double p, Map<String, Double> f) {
            symbol=s; side=d; ts=t; entry=e; tp1=target; stop=sl;
            setup=score; probability=p; features=f;
        }
    }

    private static final class Node {
        final int feature, left, right;
        final double threshold, value;
        final boolean missingLeft, leaf;
        Node(int f, double t, int l, int r, boolean ml, boolean isLeaf, double v) {
            feature=f; threshold=t; left=l; right=r; missingLeft=ml; leaf=isLeaf; value=v;
        }
    }

    private static final class Tree {
        final Node[] nodes;
        Tree(Node[] n) { nodes=n; }
        double predict(double[] x) {
            int at=0, guard=0;
            while (at>=0 && at<nodes.length && guard++<=nodes.length) {
                Node n=nodes[at];
                if (n.leaf) return n.value;
                double v=x[n.feature];
                at=(!finite(v) ? (n.missingLeft?n.left:n.right) : (v<=n.threshold?n.left:n.right));
            }
            return 0.0;
        }
    }

    private static final String[] REQUIRED_FEATURES={
            "side_sign","side_ret_1","side_ret_3","side_ret_6","side_ret_12","side_ret_24","side_ret_48",
            "side_ema20_gap","side_ema50_gap","side_ema100_gap","side_ema20_50_gap","side_rsi","atr_pct",
            "volume_ratio","side_candle_body_atr","side_close_location","range20_atr","side_btc_ret_1",
            "side_btc_ret_3","side_btc_ret_12","side_btc_ema20_50_gap","hour_sin","hour_cos","weekday_sin","weekday_cos"
    };

    static final class Model {
        final String id, trainedAt;
        final String[] names;
        final Set<String> symbols;
        final Tree[] trees;
        final double baseline, learningRate, calibrationSlope, calibrationIntercept, threshold;
        final boolean eligible;
        Model(String i, String date, String[] n, Set<String> trainedSymbols, Tree[] t, double b, double lr,
              double cs, double ci, double cutoff, boolean ok) {
            id=i; trainedAt=date; names=n; symbols=trainedSymbols; trees=t; baseline=b; learningRate=lr;
            calibrationSlope=cs; calibrationIntercept=ci; threshold=cutoff; eligible=ok;
        }
        double predict(Map<String,Double> f) {
            if (!eligible) return -1;
            double[] x=new double[names.length];
            for (int i=0;i<names.length;i++) {
                Double v=f.get(names[i]);
                if (v==null || !finite(v)) return -1;
                x[i]=v;
            }
            double raw=baseline;
            for (Tree tree:trees) raw+=learningRate*tree.predict(x);
            return sigmoid(calibrationSlope*raw+calibrationIntercept);
        }
        static Model fromJson(JSONObject o) throws Exception {
            if(o.optInt("schema_version",0)!=2 || !"hist_gradient_boosting_binary".equals(o.optString("model_type")))
                throw new IllegalArgumentException("Unsupported model format");
            if(!o.optBoolean("eligible",false)) throw new IllegalArgumentException("Model did not pass evaluation");
            JSONArray na=o.getJSONArray("feature_names");
            if(na.length()!=REQUIRED_FEATURES.length) throw new IllegalArgumentException("Unexpected feature count");
            String[] names=new String[na.length()];
            for(int i=0;i<names.length;i++) {
                names[i]=na.getString(i);
                if(!REQUIRED_FEATURES[i].equals(names[i])) throw new IllegalArgumentException("Feature order mismatch");
            }
            JSONArray sa=o.optJSONArray("symbols");
            if(sa==null || sa.length()<1) throw new IllegalArgumentException("Model has no declared training universe");
            Set<String> trainedSymbols=new HashSet<>();
            for(int i=0;i<sa.length();i++) {
                String symbol=sa.optString(i, "");
                if(symbol.matches("[A-Z0-9]{2,30}USDT")) trainedSymbols.add(symbol);
            }
            if(trainedSymbols.isEmpty()) throw new IllegalArgumentException("Invalid model training universe");
            JSONArray ta=o.getJSONArray("trees");
            if(ta.length()<1 || ta.length()>500) throw new IllegalArgumentException("Invalid tree count");
            Tree[] trees=new Tree[ta.length()];
            for(int i=0;i<trees.length;i++) {
                JSONArray rows=ta.getJSONArray(i);
                if(rows.length()<1 || rows.length()>1024) throw new IllegalArgumentException("Invalid node count");
                Node[] nodes=new Node[rows.length()];
                for(int j=0;j<nodes.length;j++) {
                    JSONArray r=rows.getJSONArray(j);
                    nodes[j]=new Node(r.getInt(0),r.getDouble(1),r.getInt(2),r.getInt(3),
                            r.getBoolean(4),r.getBoolean(5),r.getDouble(6));
                    Node node=nodes[j];
                    if(!finite(node.threshold)||!finite(node.value)) throw new IllegalArgumentException("Non-finite node value");
                    if(!node.leaf && (node.feature<0||node.feature>=names.length||node.left<0||node.left>=nodes.length||node.right<0||node.right>=nodes.length))
                        throw new IllegalArgumentException("Invalid tree link");
                }
                trees[i]=new Tree(nodes);
            }
            JSONObject cal=o.getJSONObject("calibration");
            double baseline=o.getDouble("baseline"),learningRate=o.getDouble("learning_rate");
            double slope=cal.getDouble("slope"),intercept=cal.getDouble("intercept"),threshold=o.getDouble("threshold");
            if(!finite(baseline)||!finite(learningRate)||learningRate<0||
                    !finite(slope)||!finite(intercept)||!finite(threshold)||threshold<0.5||threshold>1.0)
                throw new IllegalArgumentException("Invalid model calibration");
            return new Model(o.optString("model_id"),o.optString("trained_at_utc"),names,trainedSymbols,trees,
                    baseline,learningRate,slope,intercept,threshold,true);
        }
    }

    static Candidate analyze(String symbol, List<Candle> c, List<Candle> btc, Model model) {
        if (model==null || !model.eligible || !model.symbols.contains(symbol) || c.size()<105) return null;
        Map<String,Double> base=baseFeatures(c,btc);
        if (base==null) return null;
        Map<String,Double> longFeatures=forSide(base,1.0);
        Map<String,Double> shortFeatures=forSide(base,-1.0);
        double lp=model.predict(longFeatures), sp=model.predict(shortFeatures);
        boolean isLong=lp>=sp;
        double p=isLong?lp:sp;
        if (p<model.threshold) return null;
        String side=isLong?"LONG":"SHORT";
        double setup=setup(base,side);
        double entry=c.get(c.size()-1).close, atr=entry*base.get("atr_pct");
        if (!(atr>0) || !(entry>0)) return null;
        double stop=isLong?entry-1.15*atr:entry+1.15*atr;
        double tp=isLong?entry+1.35*atr:entry-1.35*atr;
        return new Candidate(symbol,side,c.get(c.size()-1).ts,entry,tp,stop,setup,p,
                isLong?longFeatures:shortFeatures);
    }

    private static Map<String,Double> baseFeatures(List<Candle> c, List<Candle> btc) {
        int n=c.size();
        if(n<105) return null;
        double[] close=new double[n], high=new double[n], low=new double[n], vol=new double[n];
        for(int i=0;i<n;i++){Candle x=c.get(i);close[i]=x.close;high[i]=x.high;low[i]=x.low;vol[i]=x.volume;}
        int k=n-1; double last=close[k], e20=ema(close,20), e50=ema(close,50), e100=ema(close,100);
        double atr=0;
        for(int i=n-14;i<n;i++) atr+=Math.max(high[i]-low[i],Math.max(Math.abs(high[i]-close[i-1]),Math.abs(low[i]-close[i-1])));
        atr/=14.0;
        double avgVol=0;for(int i=n-21;i<n-1;i++)avgVol+=vol[i];avgVol/=20.0;
        double min=low[n-20],max=high[n-20];
        for(int i=n-19;i<n;i++){min=Math.min(min,low[i]);max=Math.max(max,high[i]);}
        if(!(last>0)||!(atr>0)||!(e20>0)||!(e50>0)||!(e100>0))return null;
        double btcRet1=0,btcRet3=0,btcRet12=0,btcEmaGap=0;
        if(btc!=null&&btc.size()>=50){
            double[] bc=new double[btc.size()];for(int i=0;i<bc.length;i++)bc[i]=btc.get(i).close;
            int j=bc.length-1;
            btcRet1=bc[j]/bc[j-1]-1;btcRet3=bc[j]/bc[j-3]-1;btcRet12=bc[j]/bc[j-12]-1;
            btcEmaGap=ema(bc,20)/ema(bc,50)-1;
        }
        double range=Math.max(1e-12,high[k]-low[k]);
        Calendar utc=Calendar.getInstance(TimeZone.getTimeZone("UTC"),Locale.ROOT);
        utc.setTimeInMillis(c.get(k).ts);
        double hour=utc.get(Calendar.HOUR_OF_DAY), weekday=(utc.get(Calendar.DAY_OF_WEEK)+5)%7;
        Map<String,Double> f=new LinkedHashMap<>();
        f.put("ret_1",last/close[k-1]-1);f.put("ret_3",last/close[k-3]-1);
        f.put("ret_6",last/close[k-6]-1);f.put("ret_12",last/close[k-12]-1);
        f.put("ret_24",last/close[k-24]-1);f.put("ret_48",last/close[k-48]-1);
        f.put("ema20_gap",last/e20-1);f.put("ema50_gap",last/e50-1);
        f.put("ema100_gap",last/e100-1);f.put("ema20_50_gap",e20/e50-1);
        double rsi=rsi(close);f.put("rsi",(rsi-50)/50.0);f.put("atr_pct",atr/last);
        f.put("volume_ratio",Math.min(avgVol<=0?0:vol[k]/avgVol,20.0));
        f.put("candle_body_atr",(close[k]-c.get(k).open)/atr);
        f.put("close_location",2*(close[k]-low[k])/range-1);
        f.put("range20_atr",(max-min)/atr);
        f.put("btc_ret_1",btcRet1);f.put("btc_ret_3",btcRet3);f.put("btc_ret_12",btcRet12);f.put("btc_ema20_50_gap",btcEmaGap);
        f.put("hour_sin",Math.sin(2*Math.PI*hour/24));f.put("hour_cos",Math.cos(2*Math.PI*hour/24));
        f.put("weekday_sin",Math.sin(2*Math.PI*weekday/7));f.put("weekday_cos",Math.cos(2*Math.PI*weekday/7));
        return f;
    }

    private static Map<String,Double> forSide(Map<String,Double> b,double sign) {
        Map<String,Double> f=new TreeMap<>();f.put("side_sign",sign);
        String[] directional={"ret_1","ret_3","ret_6","ret_12","ret_24","ret_48","ema20_gap","ema50_gap","ema100_gap","ema20_50_gap","rsi","candle_body_atr","close_location","btc_ret_1","btc_ret_3","btc_ret_12","btc_ema20_50_gap"};
        java.util.Set<String> signed=new java.util.HashSet<>(java.util.Arrays.asList(directional));
        for(Map.Entry<String,Double> e:b.entrySet()){
            String name=e.getKey(); f.put(signed.contains(name)?"side_"+name:name,e.getValue()*(signed.contains(name)?sign:1));
        }
        return f;
    }

    private static double setup(Map<String,Double> f,String side){
        double s=side.equals("LONG")?1:-1,rsi=f.get("rsi")*50+50;
        double trend=clamp(.5+s*(.45*f.get("ema20_50_gap")+.25*f.get("ema50_gap")+.30*f.get("ret_6"))*35);
        double mom=clamp(.5+s*(.55*f.get("ret_1")+.45*f.get("ret_3"))*55);
        double fit=side.equals("LONG")?clamp((rsi-42)/24):clamp((58-rsi)/24);
        double btc=clamp(.5+s*(.45*f.get("btc_ret_3")+.35*f.get("btc_ret_12")+.20*f.get("btc_ema20_50_gap"))*25);
        double volume=clamp(f.get("volume_ratio")/2);
        return .35*trend+.25*mom+.20*fit+.10*btc+.10*volume;
    }
    static boolean finite(double x){return !Double.isNaN(x)&&!Double.isInfinite(x);}
    static double ema(double[] v,int p){double a=2.0/(p+1),x=0;for(int i=0;i<p;i++)x+=v[i];x/=p;for(int i=p;i<v.length;i++)x=a*v[i]+(1-a)*x;return x;}
    static double rsi(double[] v){double up=0,dn=0;for(int i=v.length-14;i<v.length;i++){double d=v[i]-v[i-1];up+=Math.max(0,d);dn+=Math.max(0,-d);}up/=14;dn/=14;return dn==0?(up==0?50:100):100-100/(1+up/dn);}
    static double sigmoid(double x){if(x>=0){double z=Math.exp(-Math.min(x,40));return 1/(1+z);}double z=Math.exp(Math.max(x,-40));return z/(1+z);}
    static double clamp(double x){return Math.max(0,Math.min(1,x));}
}
