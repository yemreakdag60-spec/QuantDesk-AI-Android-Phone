package com.emreakdag.quantdesk.prism;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/** Keeps local shadow outcomes and downloads only validated promoted model versions. */
final class LearningStore {
    private static final String MODEL_URL = "https://raw.githubusercontent.com/yemreakdag60-spec/QuantDesk-AI-Android-Phone/main/models/latest.json";
    private static final long MODEL_CHECK_MS = 6 * 60 * 60 * 1000L;
    private final SharedPreferences prefs;
    private final Context context;

    LearningStore(Context c) {
        context=c.getApplicationContext();
        prefs=context.getSharedPreferences("quantdesk_ai_private",Context.MODE_PRIVATE);
    }

    synchronized AiEngine.Model loadModel() {
        try {
            String saved=prefs.getString("promoted_model","");
            AiEngine.Model local=saved.isEmpty()?null:parse(new JSONObject(saved));
            if(local!=null&&local.eligible)return local;
        } catch(Exception ignored) {}
        return readBundledModel();
    }

    private AiEngine.Model readBundledModel() {
        try(InputStream in=context.getAssets().open("pretrained_model.json")) {
            BufferedReader reader=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));
            StringBuilder text=new StringBuilder();String line;while((line=reader.readLine())!=null)text.append(line);
            AiEngine.Model model=parse(new JSONObject(text.toString()));
            return model!=null&&model.eligible?model:null;
        } catch(Exception ignored) { return null; }
    }

    /** Called from the scanner worker thread; a failed update leaves the current model intact. */
    synchronized void refreshPromotedModelIfDue() {
        long now=System.currentTimeMillis();
        if(now-prefs.getLong("model_check_at",0)<MODEL_CHECK_MS)return;
        prefs.edit().putLong("model_check_at",now).apply();
        HttpURLConnection connection=null;
        try {
            connection=(HttpURLConnection)new URL(MODEL_URL).openConnection();
            connection.setConnectTimeout(8000);connection.setReadTimeout(12000);
            connection.setRequestProperty("User-Agent","QuantDeskPrismAI/1.1.0");
            if(connection.getResponseCode()!=200)return;
            BufferedReader reader=new BufferedReader(new InputStreamReader(connection.getInputStream(),StandardCharsets.UTF_8));
            StringBuilder text=new StringBuilder();String line;while((line=reader.readLine())!=null)text.append(line);
            JSONObject json=new JSONObject(text.toString());
            AiEngine.Model candidate=parse(json);
            AiEngine.Model current=loadModel();
            if(candidate!=null&&candidate.eligible&&(current==null||candidate.trainedAt.compareTo(current.trainedAt)>0))
                prefs.edit().putString("promoted_model",json.toString()).apply();
        } catch(Exception ignored) {
            // Network or parse errors do not erase the bundled/cached champion.
        } finally { if(connection!=null)connection.disconnect(); }
    }

    synchronized int labeledCount() {
        try {JSONArray a=new JSONArray(prefs.getString("records","[]"));int n=0;
            for(int i=0;i<a.length();i++){String o=a.getJSONObject(i).optString("outcome");if(o.equals("TP1")||o.equals("SL")||o.equals("TIME_EXIT"))n++;}
            return n;
        } catch(Exception e){return 0;}
    }

    synchronized void recordCandidate(AiEngine.Candidate c) {
        try {
            JSONArray a=new JSONArray(prefs.getString("records","[]"));
            for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);if(x.optString("symbol").equals(c.symbol)&&x.optLong("ts")==c.ts&&x.optString("side").equals(c.side))return;}
            JSONObject o=new JSONObject();o.put("symbol",c.symbol);o.put("side",c.side);o.put("ts",c.ts);
            o.put("entry",c.entry);o.put("tp1",c.tp1);o.put("stop",c.stop);o.put("horizon",12);
            o.put("outcome","PENDING");o.put("model_id",loadModel()==null?"":loadModel().id);
            o.put("features",mapJson(c.features));a.put(o);
            while(a.length()>5000){JSONArray trimmed=new JSONArray();for(int i=a.length()-5000;i<a.length();i++)trimmed.put(a.get(i));a=trimmed;}
            prefs.edit().putString("records",a.toString()).apply();
        } catch(Exception ignored) {}
    }

    synchronized void observe(String symbol,List<AiEngine.Candle> candles) {
        try {
            JSONArray a=new JSONArray(prefs.getString("records","[]"));boolean changed=false;
            for(int i=0;i<a.length();i++) {
                JSONObject s=a.getJSONObject(i);
                if(!s.optString("symbol").equals(symbol)||!s.optString("outcome").equals("PENDING"))continue;
                String side=s.optString("side");double tp=s.getDouble("tp1"),stop=s.getDouble("stop");long ts=s.getLong("ts");int seen=0;String result="PENDING";
                for(AiEngine.Candle c:candles) {
                    if(c.ts<=ts)continue;if(seen>=s.optInt("horizon",12))break;seen++;
                    boolean th=side.equals("LONG")?c.high>=tp:c.low<=tp;
                    boolean sh=side.equals("LONG")?c.low<=stop:c.high>=stop;
                    if(th&&sh){result="AMBIGUOUS";break;}if(th){result="TP1";break;}if(sh){result="SL";break;}
                    if(seen>=s.optInt("horizon",12))result="TIME_EXIT";
                }
                if(!result.equals("PENDING")){s.put("outcome",result);s.put("labeledAt",System.currentTimeMillis());changed=true;}
            }
            if(changed)prefs.edit().putString("records",a.toString()).apply();
        } catch(Exception ignored) {}
    }

    private static AiEngine.Model parse(JSONObject o)throws Exception {
        if(o.optInt("schema_version",0)!=2||!o.optBoolean("eligible",false))return null;
        return AiEngine.Model.fromJson(o);
    }

    private static JSONObject mapJson(Map<String,Double>m)throws Exception {
        JSONObject o=new JSONObject();for(Map.Entry<String,Double>e:new TreeMap<>(m).entrySet())o.put(e.getKey(),e.getValue());return o;
    }
}
