# Changelog

## 1.1.0

- Added the on-device QuantDesk AI inference engine and local shadow-outcome tracking to the Prism application.
- Added a separate AI model status/result card; it shows TP1-before-SL probability only for an eligible model, supported 15-minute candles, and symbols in the model training universe.
- Added fail-closed handling: rejected or missing models never produce an AI probability. The current bundled model is rejected by evaluation, so the AI card remains unavailable until a validated champion is published.
- Added the historical training and promotion workflow. Candidate models are published only after all existing evaluation gates pass.
- Changed Android package ID to `com.emreakdag.quantdesk.prism250ai`, app label to QuantDesk Prism AI, and version to 1.1.0 so it installs separately.
- Preserved Prism's market/news interface, 10M USDT volume floor, scanner, timeframes, heuristic score and its existing TP/SL calculations.
