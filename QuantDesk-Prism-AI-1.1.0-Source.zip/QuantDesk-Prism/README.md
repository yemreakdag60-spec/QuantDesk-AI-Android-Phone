# QuantDesk Prism AI 1.1.0

A separate Android installation that combines the supplied QuantDesk Prism market/news application with the QuantDesk AI on-device inference and model-update components.

- Android application ID: `com.emreakdag.quantdesk.prism250ai`
- Display name: `QuantDesk Prism AI`
- Version: `1.1.0` (version code 110)
- It installs alongside the existing Prism Haber app. It does not replace it.

## What the app does

Prism keeps its Binance USDⓈ-M live market view, order-flow metrics, OHLCV chart, journal, 250-contract scanner and 10M USDT 24-hour volume floor. Its explanatory LONG/SHORT score is a technical heuristic, not a win probability. The 72-hour asset and Bitcoin news scan can adjust that heuristic by up to 8 points; news sentiment is not an input to the ML model. Existing timeframe controls and Prism TP/SL levels remain available.

The AI panel is a separate 15-minute inference path. It reads closed 15-minute candles for the selected contract and BTC, and only analyzes symbols included in a model's declared training universe. A model must be `eligible` and have the expected schema/features before the app accepts it. If no model passes evaluation, the app explicitly shows that no probability is available. The bundled model currently fails its promotion gate, so the initial installation will show Prism's normal analysis but no AI probability until a validated model is published.

When an eligible champion is published to `models/latest.json` in the `yemreakdag60-spec/QuantDesk-AI-Android-Phone` repository, the app checks for updates about every six hours and accepts only a valid, newer eligible model. The workflow retrains from public Binance USD-M 15-minute historical data and publishes a candidate only after chronological holdout, walk-forward, calibration, cost-stress and drawdown gates pass. Passing a CI run does not mean that a model passed: the evaluation report is the source of that result.

The app stores observed AI setup outcomes privately on the phone for tracking. Those local records are not uploaded and do not directly retrain the model. Periodic model training uses the public market history pipeline. The AI estimates whether the specified TP1 is reached before SL within 12 future 15-minute bars under the model's evaluation assumptions; it cannot guarantee future outcomes. It never sends exchange orders.

## Build and install

1. Upload `QuantDesk-Prism-AI-1.1.0-Source.zip` to the root of the GitHub repository that contains this workflow. Keep the ZIP filename unchanged.
2. Ensure the workflow file is present at `.github/workflows/android.yml` in that repository.
3. In GitHub, open **Actions → Train, validate, and build QuantDesk Prism AI → Run workflow**. The same workflow also runs on `main` pushes and daily.
4. A rejected training candidate does not stop the app build; it remains disabled for probability output. Open the run's evaluation artifact to inspect training results.
5. When the APK build completes, open the run's **Artifacts** section and download `QuantDesk-Prism-AI-1.1.0`.
6. Extract the downloaded artifact on your phone and tap `app-debug.apk`. Allow installation from the browser/files app if Android asks. The new app appears as **QuantDesk Prism AI** alongside the old app.

The debug APK is for direct testing. Publishing through Google Play requires a separately signed release build.

## Checks

Run `node scripts/test-analysis.cjs` for Prism signal/news/volume/timeframe regressions and AI fail-closed checks. Run the model trainer tests with `cd ml && python -m unittest test_model.py -v`. The GitHub workflow runs both test suites before building the APK.
