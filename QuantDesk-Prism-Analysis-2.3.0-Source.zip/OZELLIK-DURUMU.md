# Prism Analiz 2.3.0 — teslim kapsamı

Son talebe göre ürün yalnız analiz içindir. Gerçek hesap bağlantısı, bakiye okuma, emir, üyelik/VIP ödeme, KYC ve para transferi kapsamdan çıkarıldı. APK ve sunucuda gerçek emir uçları yoktur. Senaryo takibi sanaldır.

## Doğrudan uygulamada bulunanlar

| Alan | Eklenen işlev | Sınır / doğru yorum |
|---|---|---|
| Canlı veri | Binance Spot ve USDⓈ-M WebSocket, yeniden bağlantı, REST yedeği, kaynak/zaman damgası | Ağ/borsa erişimi gerekir; kopmada eski veri açıkça işaretlenir |
| Oluşan mum | Açık mum akıştan güncellenir; kapanan mum eklenir | Özel periyot ortasında bağlanılmışsa ilk mum eksik işaretlenir |
| Canlı giriş/ hedef | Güncel fiyat, giriş bandı, TP uzaklığı ve net risk/getiri | Referans hedef sonradan fiyatı izleyerek kaydırılmaz; 45 sn veri eskiliği, 0,4 ATR giriş bandı, hedef/stop ve 6 mumda 2,5 ATR geç hareket kontrol edilir |
| Otomatik radar | En yüksek hacimli 250 USDT paritesi, varsayılan 10 milyon USDT/24s hacim filtresi, spot/vadeli, skor sıralaması, long/short/favori filtreleri, BTC/üst zaman teyidi | 250 koşulu sağlayan parite yoksa düşük hacimliyle doldurmaz; cihaz görünürken çalışır; kapalı telefon için sunucu gerekir |
| İki aday | En yüksek puanlı iki mevcut analiz ayrıca gösterilir | Uygun değilse bekle; veri yokken sinyal uydurulmaz |
| Risk büyüklüğü | Stop mesafesi, sanal özkaynak, ücret ve 4 baz puan kayma varsayımına göre nominal büyüklük hesaplayıcı | Basit sanal portföyde kaldıraç 1× varsayılır; gerçekleşen kayıp farklı olabilir |
| Likidite filtresi | Radar evreni, 50 bp üstü spreadi veya 2.500 USDT altında üst kademe derinliği olan coinleri dışlar | Yalnız en iyi alış/satış kademesi fotoğrafıdır; tam emir defteri/gerçek gerçekleşebilirlik ölçümü değildir |
| BTC'ye göre göreceli performans | 30/90 günlük coin getirisi eksi BTC getirisi gösterilir | Yeterli eşleşmiş günlük veri gerekir; ayrı piyasa endeksi değildir |
| Sinyal geri bildirimi | Faydalı/geç/hatalı/açıklama yetersiz işaretleri cihazda saklanır | Otomatik model eğitimi veya sonuç doğrulaması değildir |
| Periyot | 1/3/5/10/15/20/25/30/45 dk; 1/2/4/6/12 saat; 1 gün | Özel periyotlar tam 5 dk mumlardan UTC'ye hizalı oluşturulur; boşluklar elenir |
| Göstergeler | EMA21/55, RSI14, ATR14, MACD12/26/9, hacim oranı, seçili zaman diliminde BTC korelasyonu; 30/90 günlük BTC korelasyon ve beta; ADX/DMI, ham Stoch RSI14/14, VWAP, Bollinger | Yeterli günlük geçmiş gerekir; yüksek BTC korelasyonu ile ters BTC günlük yönü sinyali beklemeye alır. Skor yüzde kazanma olasılığı değildir |
| Yapı | Son 20 mum destek/direnç, aralık kırılımı, doji/yutan mum/uzun fitil kuralları | Tek başına güvenilir işlem kararı veya başarı garantisi değildir |
| Çoklu zaman | 1m/5m/15m/1h/4h/1d yön, skor, RSI, ADX matrisi | Farklı anlarda alınan kapanmış mumlar, tek olasılık puanı değil |
| Grafik araçları | Yatay çizgi, trend, Fibonacci; yakınlaştırma/kaydırma; RSI/Bollinger; replay; yaklaşık hacim profili/POC | Profil mum hacmini fiyat aralığına dağıtır; gerçek geçmiş tick profili değil |
| Çoklu grafik | Dört paritenin 60 mum görünümü ve analiz karşılaştırması | Dört bağımsız tam TradingView terminali değil |
| Kişisel kurallar | JSON editörü: RSI, Stoch RSI, ADX, DMI, bant genişliği, MACD histogramı, skor, R/G | Güvenli karşılaştırma kuralları; Pine Script derleyicisi değil |
| Backtest | 1.000/3.000 mum; %70 eğitim/%30 ayrılmış test; maliyetler; net sonuç, kâr faktörü, düşüş, Wilson aralığı | EMA/ATR araştırma stratejisi; radarın tüm filtrelerinin başarısı sayılmaz |
| Walk-forward | Kayan 700 eğitim / 300 test; örtüşmeyen test pencereleri; dönem sonuçları | Pencereler bağımsız 10.000 USDT ile başlar; toplam bileşik portföy getirisi değildir |
| Parametre öğrenimi | Eğitimde ATR stop/hedef ızgara seçimi; ≥30 test işlemi, net pozitif, PF>1,1; kullanıcı etkinleştirir, 7 gün geçerli | Sürekli kendini geliştiren genel AI/tahmin modeli değil; gelecek TP olasılığı kalibre değil |
| TP1/TP2 takibi | Sanal TP1 %50 kapanış, kalan stop girişe; TP2 kalanını kapatır; olay bazlı takip | Ağ kesintisinde kaçan dokunuşlar gerçekleşmiş yazılmaz; başa baş stop net sıfır kâr garantisi değil |
| Risk senaryosu | 1–20× sanal vadeli, spot 1×; komisyon, kayma, izole teminat/likidasyon/fonlama modeli | Likidasyon %0,5 bakım marjıyla yaklaşık; gerçek borsa kademeleri değil |
| Piyasa akışı | İzlenen büyük borsa işlemleri, oturum footprint, Binance likidasyon olayları, son 1 saat/5 dk yoğunluk görünümü | Zincir üstü transfer veya gelecekteki likidasyon tahmini olarak sunulmaz; arşiv değil |
| Vadeli bağlam | Açık pozisyon, fonlama, mark/endeks ve baz farkı | Kullanıcı yenilemeli anlık veri fotoğrafı |
| Duyarlılık | Alternative.me korku/açgözlülük, tarih ve kaynak | Kamu API erişimi gerekir |
| Borsa karşılaştırma | Binance BTC/USDT, OKX BTC/USDT, Coinbase BTC/USD referansları | USD/USDT ve alınma anları farklı; arbitraj ya da geniş çoklu borsa motoru değil |
| Alarmlar/kayıt | Cihazda favoriler, çizimler, fiyat alarmı ve izinle Android bildirimleri; CSV/JSON dışa aktarma | Yerel alarm uygulama çalışırken tetiklenir |

## 2.3.0 kapsamına eklenen kontroller

- İleri görünüm, 1/4/12 mum ufukları için geçmiş kapanmış getirilerin ampirik %20/%50/%80 fiyat aralığını ve geçmiş yön sıklığını gösterir. Kayan örnekler örtüşebilir; değerler AI tahmini veya kalibre edilmiş gelecek olasılığı değildir.
- Altı kapanmış mumdaki tek yönlü hareket 2,5 ATR’yi aşarsa sinyal “geç” kabul edilir ve uygun aday olmaktan çıkarılır. Eski fiyat, giriş bandından uzaklaşma ve hedef/stop aşımı ayrıca engellenir.
- Tarama varsayılan olarak 250 coin ve en az 10 milyon USDT/24 saat hacim kullanır. Gerçek piyasa evreni daha küçük kalırsa sayı yapay biçimde tamamlanmaz.
- Tarama, 50 bp üzeri spreadi ve en iyi kademe başına 2.500 USDT altı görünen derinliği olan varlıkları eler.
- Risk büyüklüğü aracı; sanal özkaynak, stop uzaklığı, komisyon ve 4 bp kayma varsayımına göre nominal pozisyon miktarını hesaplar. Sinyal detayında 30/90 günlük BTC'ye göre göreceli performans gösterilir.
- Kullanıcı sinyal ayrıntısını faydalı/geç/hatalı/açıklaması yetersiz olarak işaretleyebilir; geri bildirim bu cihazda saklanır.
- Haber başlıkları kaynak alan adına göre doğrulanır, aynı başlık birleştirilir ve olay türü etiketlenir.

## Kodları var; dış bağlantı/kurulum gerektiriyor

| Hizmet | Gerekli olan | Teslimdeki durum |
|---|---|---|
| 7/24 tarama/takip | Sürekli çalışan kişisel Node.js sunucusu veya bilgisayar | Kod + Docker/Caddy örneği var; uzak sunucu kurulmadı |
| Bulut eşitleme | HTTPS sunucu + kişisel erişim anahtarı | Favori/çizim/model aktarımı, sürüm çakışması koruması var; hesap bağlı değil |
| Telefon kapalıyken alarm | Sunucu + isteğe bağlı Telegram bot yapılandırması | Adaptör var; gerçek hesaba bağlanmadı; FCM/APNs yok |
| Gerçek AI sohbet | Erişilebilir Ollama ve indirilmiş model | Analiz bağlamlı gerçek API isteği var; bu teslimde model bağlı değil |
| Haber | Sunucudan CoinDesk/Cointelegraph RSS; tekrar başlıklarını birleştirme, olay sınıfı, izinli HTTPS kaynak bağlantısı ve zaman | Yalnız analiz bağlamıdır; sunucu ve sağlayıcı erişimine bağlı |
| Zincir üstü balina | Uyumlu Whale Alert aboneliği/API anahtarı | Gerçek WebSocket adaptörü var; abonelik sağlanmadı |

Sunucu senaryoları cihaz portföyünden ayrıdır. Kişisel filtre ve öğrenilmiş ATR parametresi cihaz motoruna uygulanır; sunucu radarı standart motoru kullanır.

## Tamamlanmamış analiz özellikleri

- Pine Script motoru, bütün TradingView göstergeleri/çizim araçları/sosyal özellikleri.
- Tüm borsalarda eksiksiz order-flow/footprint geçmişi ve gelecekteki likidasyon seviyeleri heatmap'i.
- Mevcut her sinyal için doğrulanmış hedefe ulaşma olasılığı, büyük veriyle eğitilmiş özel tahmin modeli ve her yenilemede iyileşme garantisi.
- Sınırsız/tam özellikli bağımsız çoklu grafik çalışma alanı ve geniş çoklu borsa analiz taraması.

Dolayısıyla bütün ticari uygulamaların bütün analiz işlevleri tamamlandı iddiası yoktur. Uygulamada bulunan işlevlerle dış hizmet gerektirenler yukarıda ayrılmıştır.

## Dosya boyutu

ZIP metin kaynak kodunu sıkıştırır. APK işletim sisteminin WebView'ini kullanır; Chromium, tüm piyasa geçmişi veya AI modeli içine gömülmez. Bu yüzden boyutu MB'larca büyütmek kalite ölçüsü değildir. Gerçek işlev durumu bu tablo ve doğrulama raporuyla değerlendirilmelidir.

## Teknik kaynaklar

Gösterge tanımları: TradingView resmî yardımındaki [ADX](https://www.tradingview.com/support/solutions/43000589099-average-directional-index-adx/), [DMI](https://www.tradingview.com/support/solutions/43000502250-directional-movement-dmi/), [VWAP](https://www.tradingview.com/support/solutions/43000502018-volume-weighted-average-price-vwap/), [Stoch RSI](https://www.tradingview.com/support/solutions/43000502333-stochastic-rsi-stoch-rsi/). Bu uygulamadaki kuralların ve yaklaşık hesapların sınırları ayrıca açıklanmıştır; TradingView ile birebir sonuç eşitliği iddia edilmez.
