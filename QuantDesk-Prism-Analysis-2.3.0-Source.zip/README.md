# Prism Analiz 2.3.0

Emre Akdağ'ın son kapsam düzeltmesi: **yalnız analiz, gerçek alım satım yok.** Android uygulaması, analiz motorları ve isteğe bağlı kişisel sunucu kaynakları birlikte verilir. Borsa API anahtarı girişi, bakiye, gerçek emir gönderme ve ödeme/para transferi kodu bulunmaz. Sanal senaryo takibi analizlerin TP/SL sonuçlarını ölçmek içindir.

## Yeni analiz kontrolleri

- Varsayılan tarama evreni 250 USDT paritesidir; varsayılan 24 saat hacim tabanı 10 milyon USDT. Eşiği geçen parite sayısı 250’den azsa düşük hacimli varlıklarla doldurulmaz.
- Sinyal kartında son altı mumun tek yönlü hareketi 2,5 ATR’yi aşarsa aday geç sinyal olarak engellenir ve geri çekilme beklenir. Anlık giriş ayrıca fiyat yaşı, 0,4 ATR giriş bandı ve hedef/stop geçerliliğiyle yeniden doğrulanır.
- Tarama sırasında yeterli günlük geçmişi olan paritelerde 30/90 günlük BTC korelasyonu ve beta hesaplanır. Her iki pencerede yüksek korelasyon ve BTC günlük yönü ters ise sinyal beklemeye alınır.
- Tarama evrenine girmeden önce en iyi alış/satış farkı ve en iyi kademedeki yaklaşık USD derinliği kontrol edilir; 50 baz puanın üstündeki spread veya 2.500 USDT altındaki üst-kademe derinliği elenir. Bu ölçüm tam emir defteri derinliği garantisi değildir.
- Coin detayında BTC’ye göre 30/90 günlük göreceli getiri ve komisyon/kayma varsayımlı stop-mesafesi risk büyüklüğü hesaplayıcısı bulunur. Boyut hesabı garanti ya da yatırım tavsiyesi değildir.
- Analiz detayında faydalı/geç/hatalı/açıklaması yetersiz geri bildirimi cihazda saklanır; performansın otomatik doğrulaması yerine geçmez.
- Sinyal ayrıntısı, 1/4/12 mum ufkunda geçmiş kapanmış getirilerin %20/%50/%80 ampirik senaryo aralığını gösterir. Bunlar AI tahmini veya kalibre edilmiş gelecek olasılığı değildir; kayan örnekler örtüşebilir.
- Sunucu haber akışı başlık kopyalarını birleştirir, olay türü sınıflandırır ve yalnız izin verilen CoinDesk/Cointelegraph HTTPS kaynak bağlantılarını gösterir.

## Kurulum

Android 8.0+; güncel Android System WebView gerekir. Bu kaynak paketinden 2.3.0 APK henüz derlenmedi; Android SDK/Gradle bulunan GitHub Actions koşusu gerekir. Paket kimliği `com.quantdesk.prism.analysis`; eski uygulamaları silmeden ayrı kurulur. Eski uygulamadaki veriler otomatik taşınmaz. Oluşturulursa teslim debug/test imzalı olur, mağaza yayını değildir.

1. Uygulamayı aç, Spot veya Vadeli analiz seç. Canlı veriler halka açık borsa uçlarından alınır.
2. Radar, otomatik taramayı tamamlandıktan 120 saniye sonra tekrarlar. Ayarlarda 30/60/120/300 saniye seçilebilir. Ağ kısıtı varsa açık hata gösterilir.
3. Kartta son fiyat, giriş referansı/bandı, hedef uzaklığı ve güncel net risk/getiri görünür. Sinyalin hedefleri fiyatı izleyerek sonradan kaydırılmaz.
4. Terminal: oluşan mum, çizimler, RSI/Bollinger, hacim, replay, yaklaşık POC, ADX/DMI, Stoch RSI, VWAP, MACD, mum biçimi ve altı zaman dilimi matrisi.
5. Araştırma: ayrı eğitim/test backtest, walk-forward, dört parite mum görünümü, piyasa akışı, duyarlılık ve isteğe bağlı gerçek AI bağlantısı.
6. Senaryo takibi: sanal giriş yeniden doğrulanır; TP1 yarısını kapatır, kalan stop girişe taşınır, TP2 kalanını kapatır. Gerçek emir oluşturulmaz.

## Tam kaynak ve GitHub

ZIP adını değiştirmeden depo köküne yükleyin: `QuantDesk-Prism-Analysis-2.3.0-Source.zip`.
Teslim edilen `Prism-Analiz-2.3.0-android.yml` içeriğini **`.github/workflows/android.yml`** dosyasına koyun. Actions → **Build Prism Analysis 2.3 APK** → Run workflow.
Başarılı çalışmanın Artifacts bölümündeki `Prism-Analiz-2.3.0-APK` paketini indirin. Eski Autopilot/Aegis workflow'ları farklı işlerdir; bu iş akışını seçin. ZIP açılmış proje olarak da derlenebilir.

Java 17, Gradle 8.9, SDK 35 / build-tools 34.0.0:

```sh
node --test tests/engine.test.cjs tests/quant.test.cjs tests/analytics.test.cjs tests/server.test.cjs tests/monitor.test.cjs
gradle --no-daemon :app:assembleDebug :app:lintDebug
```

Tarayıcı testi için Playwright kurulur; `node tests/pro-ui.test.cjs`. Kendi Chromium ikilisi varsa `CHROMIUM_PATH` ile yolu verilir. Ekran görüntüleri örnek veriyle oluşturulan arayüz testleridir.

## Sunucu gerekir mi?

Cihaz açıkken temel canlı analiz için gerekmez. Telefon kapalıyken 7/24 tarama, kayıt, Telegram alarmı, bulut eşitleme ve Ollama AI için sürekli çalışan kendi bilgisayarınız veya sunucunuz gerekir. Sunucu bu teslimde uzak bir makineye kurulmuş değildir. Kurulum: `server/README.md`.

## Sınırlar

`OZELLIK-DURUMU.md`, doğrudan çalışan, dış bağlantı isteyen ve tamamlanmamış özelliklerin tamamını ayırır. Pine Script motoru ve tüm ticari uygulamaların bütün kapalı özellikleri kopyalanmış değildir. Kazanma olasılığı doğrulanmadan yüzde sunulmaz; uygun sinyal yokken iki sahte fırsat üretilmez.
