# Prism Analiz 2.3.0 doğrulama durumu

## Çalıştırılan kontroller

- `node --test tests/analytics.test.cjs tests/engine.test.cjs tests/monitor.test.cjs tests/quant.test.cjs tests/server.test.cjs`: 46 test geçti. Yeni testler risk bazlı miktar hesabı, BTC’ye göre göreceli getiri ve spread/üst-kademe derinlik filtresini doğrular.
- `node --check` ile değiştirilen `app.js` ve `engine.js` sözdizimi doğrulandı.
- `tests/pro-ui.test.cjs` çalıştırılamadı; gerekli Chromium çalıştırılabilir dosyası ortamda yok.

## Henüz doğrulanmayanlar

- Android APK derlenmedi: çalışma alanında Android SDK ve Gradle yok.
- Fiziksel Android cihazında etkileşim ve görünüm testi yapılmadı.
- Binance canlı API yanıtıyla spread/derinlik filtresi uçtan uca denenmedi.
- Kişisel sunucu, Telegram, Ollama ve Whale Alert hesap/API anahtarları bağlanmadı.
- GitHub Actions çalıştırılmadı; kaynak GitHub'a yüklenmedi.

Bu testler 106 maddenin tümünün tamamlandığını veya uygulamanın hatasız olduğunu kanıtlamaz.
