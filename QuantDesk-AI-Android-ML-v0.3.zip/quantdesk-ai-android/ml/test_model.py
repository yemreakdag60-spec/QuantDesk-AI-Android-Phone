import importlib.util
import datetime as dt
import pathlib
import unittest

import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier

SCRIPT = pathlib.Path(__file__).with_name("train_model.py")
spec = importlib.util.spec_from_file_location("quantdesk_train_model", SCRIPT)
trainer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(trainer)


class TrainingPipelineTests(unittest.TestCase):
    def test_archive_source_uses_official_um_paths_and_closed_daily_files(self):
        urls = trainer._archive_urls(
            "BTCUSDT", dt.date(2026, 8, 29),
            dt.date(2026, 10, 13), dt.date(2026, 10, 13),
        )
        self.assertTrue(any("/monthly/klines/BTCUSDT/15m/BTCUSDT-15m-2026-08.zip" in u for u in urls))
        self.assertTrue(any("/daily/klines/BTCUSDT/15m/BTCUSDT-15m-2026-09-01.zip" in u for u in urls))
        self.assertTrue(any("/daily/klines/BTCUSDT/15m/BTCUSDT-15m-2026-10-12.zip" in u for u in urls))
        self.assertFalse(any("2026-10-13.zip" in u for u in urls))

    def test_exported_tree_inference_matches_sklearn(self):
        rng = np.random.default_rng(31)
        x = rng.normal(size=(1600, len(trainer.FEATURES))).astype(np.float32)
        y = (x[:, 0] - 0.4 * x[:, 1] + rng.normal(size=len(x)) * 0.7 > 0).astype(np.uint8)
        model = HistGradientBoostingClassifier(
            max_iter=18, max_leaf_nodes=7, min_samples_leaf=20,
            learning_rate=0.05, early_stopping=False, random_state=7,
        ).fit(x[:1200], y[:1200])
        exported = {
            "baseline": float(model._baseline_prediction[0, 0]),
            "learning_rate": 1.0,
            "trees": [trainer.export_tree(stage[0]) for stage in model._predictors],
        }
        actual = trainer.exported_raw(exported, x[1200:])
        expected = model.decision_function(x[1200:])
        np.testing.assert_allclose(actual, expected, atol=1e-6, rtol=0)

    def test_training_and_probability_calibration_run_end_to_end(self):
        rng = np.random.default_rng(33)
        x = rng.normal(size=(5600, len(trainer.FEATURES))).astype(np.float32)
        latent = 0.9 * x[:, 0] - 0.5 * x[:, 1] + 0.25 * x[:, 12]
        y = (latent + rng.normal(size=len(x)) > 0).astype(np.uint8)
        exported, _ = trainer.fit_and_export(x[:4000], y[:4000], x[4000:], y[4000:])
        p = trainer.model_prob(exported, x[4000:])
        self.assertTrue(np.isfinite(p).all())
        self.assertTrue(((p >= 0) & (p <= 1)).all())
        self.assertEqual(len(exported["trees"]), 180)

    def test_features_are_finite_and_directional_schema_matches(self):
        rng = np.random.default_rng(32)
        n = 1600
        ts = np.arange(n, dtype=np.int64) * trainer.BAR_MS + 1_700_000_000_000
        close = 100 * np.exp(np.cumsum(rng.normal(0.0001, 0.004, n)))
        op = np.r_[close[0], close[:-1]]
        high = np.maximum(op, close) * (1 + rng.uniform(0, 0.002, n))
        low = np.minimum(op, close) * (1 - rng.uniform(0, 0.002, n))
        volume = rng.lognormal(4, 0.5, n)
        raw = np.column_stack([ts, op, high, low, close, volume])
        base, candle_ts = trainer.feature_frame(raw, {})
        btc = {
            int(t): (float(base[i, 0]), float(base[i, 1]), float(base[i, 3]), float(base[i, 9]))
            for i, t in enumerate(candle_ts) if i >= 12
        }
        x, y, returns, sample_ts, symbols = trainer.build_samples(raw, btc, 1)
        self.assertEqual(x.shape[1], len(trainer.FEATURES))
        self.assertTrue(np.isfinite(x).all())
        self.assertEqual(len(x), len(y))
        self.assertEqual(len(x), len(returns))
        self.assertTrue(set(np.unique(y)).issubset({0, 1}))

    def test_chronological_windows_have_embargo_gaps(self):
        ts = np.arange(20_000, dtype=np.int64) * trainer.BAR_MS
        windows = trainer.split_windows(ts)
        train_end = ts[windows["train"]].max()
        cal_start = ts[windows["cal"]].min()
        cal_end = ts[windows["cal"]].max()
        select_start = ts[windows["select"]].min()
        select_end = ts[windows["select"]].max()
        test_start = ts[windows["test"]].min()
        self.assertGreaterEqual(cal_start - train_end, 2 * trainer.HORIZON * trainer.BAR_MS)
        self.assertGreaterEqual(select_start - cal_end, 2 * trainer.HORIZON * trainer.BAR_MS)
        self.assertGreaterEqual(test_start - select_end, 2 * trainer.HORIZON * trainer.BAR_MS)

    def test_threshold_backtest_keeps_higher_probability_direction(self):
        same_symbol_time = [
            (0, 3, 0.72, -0.01), (0, 3, 0.86, 0.02),
            (trainer.HORIZON * trainer.BAR_MS, 3, 0.80, 0.01),
        ]
        rows = trainer.non_overlapping(same_symbol_time, 0.70)
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0][2], 0.86)


if __name__ == "__main__":
    unittest.main()
