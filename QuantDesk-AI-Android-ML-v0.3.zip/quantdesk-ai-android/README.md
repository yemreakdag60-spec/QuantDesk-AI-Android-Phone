# QuantDesk AI Android 0.3

This project contains an Android market scanner and a separate model-training pipeline. The Android app does not train a neural network on the phone. GitHub Actions downloads public Binance USDⓈ-M perpetual 15-minute candles from Binance's official `data.binance.vision` archive, trains a gradient-boosted tree classifier, calibrates its probabilities, chooses a decision threshold on a later period, and checks it on a final unseen chronological period. This archive route avoids the exchange-info and ticker REST endpoints that returned HTTP 451 in the previous workflow run. The training universe is a fixed list of up to 24 established USDT perpetuals; symbols without enough archive history are skipped.

## What must pass before an APK is built

The candidate needs enough non-overlapping observations, positive validation and holdout expectancy after the configured 12-basis-point round-trip cost assumption, a positive block-bootstrap lower bound, drawdown no greater than 25%, better holdout Brier score than the training prevalence baseline, and AUC of at least 0.52. When an existing champion is available, a new candidate must also beat it on the same holdout. If checks fail and no champion exists, the workflow stops before producing an APK. It uploads `model_report.json` to explain the result.

The tests in `ml/test_model.py` cover feature creation, chronological embargoes, model export parity, and threshold selection. Passing these code tests does not establish trading performance; only the live-data holdout report can do that.

## Ongoing updates

The workflow runs on a daily schedule and when the source ZIP changes. It only replaces `models/latest.json` when a candidate passes the gates; otherwise it retains the existing validated model. The Android app checks that file every six hours and retains its cached model if an update cannot be downloaded.

The app stores its own shadow outcomes on the phone. It does not upload those private records. Daily training uses public candle history and derives TP/SL labels from it, so phone-specific outcomes are not currently fed into training.

## Assumptions and limits

- Signals use closed 15-minute candles and a 12-candle (three-hour) TP-before-SL horizon.
- The backtest uses 1.35 ATR for TP1, 1.15 ATR for the stop, and a 0.12% round-trip cost assumption. Funding and sudden slippage beyond that assumption are not modeled.
- A fixed list of established contracts defines the training universe; historical survivorship bias is possible, and this is not a dynamic top-volume ranking.
- The holdout is chronological, but it is still a historical simulation. It cannot guarantee future accuracy, profitability, or protection from losses.
- The app only displays analysis candidates. It does not place orders.

## Build

The repository workflow expects `QuantDesk-AI-Android-ML-v0.3.zip` at the repository root. It tests and trains the model before building `app-debug.apk`. The APK is available as a GitHub Actions artifact only when an eligible model is present. If archive data is blocked or the candidate fails the holdout gates, the training report artifact includes the reason.
