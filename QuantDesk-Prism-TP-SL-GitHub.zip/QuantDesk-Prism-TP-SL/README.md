# QuantDesk Prism TP/SL düzeltmesi

Bu depo, yüklediğiniz `app-debug.apk` dosyasını temel alır. Uygulamanın diğer APK üyelerini yeniden derlemez veya yeniden sıkıştırmaz. Yama betiği yalnızca aşağıdaki dosyalara dokunur:

- `assets/prism-engine.js`: ATR ve 12 mumluk erişilebilirlik sınırına göre SL/TP üretimi.
- `assets/prism-app.js`: erişilebilir olmayan TP satırını sonuç kartında göstermeme.
- `AndroidManifest.xml` içindeki paket kimliği: önceki kurulumun yanına ayrı uygulama kurulabilmesi için.

Diğer APK üyelerinin sıkıştırılmış içerikleri aynen korunur. Eski APK imza kayıtları kaldırılır ve GitHub Actions çıktısı Android Build Tools ile v1/v2/v3 imzalanır.

## GitHub'da APK üretme

1. Bu arşivi açıp içindeki dosyaları yeni bir GitHub deposuna yükleyin.
2. Depoda **Actions** sekmesini açın.
3. **Build QuantDesk Prism TP-SL APK** iş akışını seçip **Run workflow** başlatın.
4. Tamamlanınca **QuantDesk-Prism-TP-SL** adlı artifact'i indirin; içinden APK'yı çıkarıp telefona yükleyin.

İlk derleme için imzalama sırrı tanımlamak gerekmez. GitHub geçici imza anahtarı oluşturur. Bu durumda yeni derlemeyi güncelleme olarak kurarken imza uyuşmazlığı olursa önce uygulamanın o kopyasını kaldırın. Aynı anahtarla sonraki APK'ları güncellemek için GitHub deposunun **Settings → Secrets and variables → Actions** bölümüne `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS` ve `KEY_PASSWORD` sırlarını ekleyin.

Paket kimliği `com.emreakdag.quantdesk.prism250newx` olarak ayarlanmıştır. Uygulama görünen adı değiştirilmemiştir.
