# Crypto Analiz 106 — doğrulama

## Çalıştırıldı

- 50/50 Node.js testleri: teknik göstergeler, giriş/stop verifikasyonu, long/short sanal pozisyon, 5 hedefli çıkış, risk miktarı, BTC beta/göreceli güç, evren filtresi, araştırma motoru, sunucu erişim kontrolleri, haber adaptörü ve yeni sinyal arşivi durum makinesi.
- `node --check` tüm `app/src/main/assets/*.js` ve `server/*.cjs` dosyalarında başarılı.
- Sinyal arşivi testleri: yinelenen kayıt önleme, veri/kural kaynağı, giriş teyidi, 5 hedef sırası, stop, short yönü, süre sonu ve restore doğrulandı.
- Ayrı paket kimliği kaynak ve Android manifestte `com.emreakdag.cryptoanaliz106` olarak kontrol edildi.

## Çalıştırılamadı

- APK assemble ve Android lint: yerel ortamda Android SDK/Gradle yok. GitHub Actions iş akışı eklendi, ancak bu konuşmada çalıştırılmadı.
- Fiziksel Android kurulumu/görsel testi: bağlı cihaz yok.
- Playwright arayüz testi: Chromium çalıştırılabilir dosyası mevcut değil.
- Canlı Binance/RSS/AI/Whale Alert uçtan uca test: sağlayıcı ağı/anahtar/abonelik gerektirir; gerçek servis kurulumu yapılmadı.

## Sonuç

Bu kanıtlar APK'nın derlendiğini veya her ekrandaki tüm davranışın Android cihazında doğrulandığını göstermez. 106 maddenin her birinin uygulamadaki durumu `OZELLIK-DURUMU.md` içinde açıkça işaretlenmiştir. Kısmi/eksik maddeler tamamlanmış sayılmaz.
