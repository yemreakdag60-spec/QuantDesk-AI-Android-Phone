# Crypto Analiz 106

106 maddelik kapsam için **ayrı Android uygulama projesi**. Önceki Prism/QuantDesk paketinin üstüne güncelleme değildir.

- Uygulama adı: **Crypto Analiz 106**
- Paket kimliği: `com.emreakdag.cryptoanaliz106` (önceki uygulamadan ayrı kurulabilir)
- Sürüm: `1.0.0` (versionCode 100)
- Kapsam: analiz ve sanal pozisyon takibi; gerçek emir, hesap anahtarı, bakiye veya alım satım uçları yok.
- 106 maddeyi tek tek kod karşılığı ve sınırıyla değerlendiren belge: [OZELLIK-DURUMU.md](OZELLIK-DURUMU.md)

## APK durumu

Bu çalışma alanında Android SDK/Gradle ve bağlı fiziksel Android cihaz bulunmadığından burada APK derlemesi veya cihaz kurulumu yapılmadı. `.github/workflows/android.yml`, bu ayrı projeyi GitHub Actions’ta derleyip lint/test çalıştırdıktan sonra `Crypto-Analiz-106-1.0.0-APK` adlı APK artifact'i üretmek için hazırlandı. Action başarılı olmadan bu kaynak ZIP'i kurulabilir APK değildir.

## Derleme ve doğrulama

Gereksinimler: Java 17, Android SDK 35/build-tools 34.0.0, Gradle 8.9, Node.js 24.

```sh
node --test tests/engine.test.cjs tests/quant.test.cjs tests/analytics.test.cjs tests/server.test.cjs tests/monitor.test.cjs tests/signal-history.test.cjs
gradle --no-daemon :app:assembleDebug :app:lintDebug
```

Playwright/Chromium varsa arayüz testi: `node tests/pro-ui.test.cjs`.

## Analiz yaklaşımı

Sinyal skoru açıklanabilir, kural tabanlı uyum puanıdır; kazanma olasılığı değildir. Göstergeler, veri sağlayıcısı, fiyat ve mum zamanı, sinyal eşikleri ve ampirik ileri senaryo sınırları uygulama içinde açıklanır. Uygulamada eğitilmiş AI/ML sinyal modeli yoktur. Geç sinyal filtresi, 250 pariteye kadar hacim ve likidite taraması, BTC korelasyon/beta bağlamı, risk boyutlama, 5 hedefli sanal çıkış ve sinyal geçmişi bulunur.

Tam durum ve sınırlamalar `OZELLIK-DURUMU.md` içindedir. API/AI/haber/24×7 bildirim gibi dış hizmetler hesap, anahtar veya kişisel sunucu gerektirebilir; bu teslim için uzaktaki hizmetler kurulmadı.
