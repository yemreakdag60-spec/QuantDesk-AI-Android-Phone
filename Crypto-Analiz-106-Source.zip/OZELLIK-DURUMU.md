# Crypto Analiz 106 — 106 madde izlenebilirlik tablosu

Bu tablo yeni ve ayrı uygulama paketini (`com.emreakdag.cryptoanaliz106`) değerlendirir. Durumlar kodda görülen kapsamı anlatır; “eksik/kısmi” olanı tamamlandı diye saymaz. 11–20 numaralı maddeler eski Crypto Signals Ultimate uygulamasının kamuya açıklamadığı yöntemlerle ilgiliydi; yeni uygulamada kendi yöntemimiz açıklanmıştır, eski uygulamanın iç algoritmasının keşfedildiği iddia edilmez.

| # | Gereksinim | Durum | Uygulamadaki karşılık / sınır |
|---:|---|---|---|
| 1 | Uygulamanın adı Crypto Signals Ultimate; ekran görüntüsünde görülen sürüm 1.0.1’dir. | **Uygulandı** | Crypto Analiz 106 / 1.0.0; applicationId ayrı. |
| 2 | Uygulama kripto para piyasasına yönelik long ve short sinyal/analiz çıktıları sunduğunu belirtir. | **Uygulandı** | Kural tabanlı LONG/SHORT analiz motoru. |
| 3 | Sinyal kartlarında yön bilgisi (long/short) yer alabilir. | **Uygulandı** | Sinyal kartı yön rozeti. |
| 4 | Sinyal için giriş veya güncel fiyat bilgisi verilebilir. | **Uygulandı** | Giriş referansı ve güncel fiyat. |
| 5 | Stop-loss seviyesi gösterilebilir. | **Uygulandı** | Stop seviyesi gösterimi. |
| 6 | Birden fazla kâr alma hedefi (TP) gösterilebilir; tanıtımda beş hedef belirtilmiştir. | **Uygulandı** | 5 hedef, kademeli çıkış ve test. |
| 7 | Stop mesafesine bağlı kaldıraç önerisi sunulduğu belirtilir. | **Kısmi** | 1–20× sanal kaldıraç seçimi var; sinyalden otomatik kaldıraç tavsiyesi üretilmiyor. |
| 8 | İşlem başına hesap riskine üst sınır önerisi bulunduğu belirtilir. | **Uygulandı** | %0,1–5 risk girişi ve stop mesafesine göre boyut hesabı. |
| 9 | Yeni sinyaller için anlık bildirim gönderme özelliği tanıtılır. | **Kısmi** | Android yerel bildirim köprüsü ve fiyat uyarısı var; her yeni sinyal için bağımsız push servisi/FCM kurulu değil. |
| 10 | Gösterge panelinde 7 gün, 30 gün, 3 ay ve 1 yıl dönemleri; geçmiş sinyal ve sonuç özeti bulunduğu belirtilir. | **Uygulandı** | 7/30/90/365 günlük sanal sonuç özetleri. |
| 11 | Kullanılan teknik göstergelerin tam listesi ve parametreleri kamuya açık biçimde doğrulanamamıştır. | **Açıklandı** | EMA 21/55, RSI14, ATR14, MACD12/26/9, ADX/DMI, Stoch RSI, VWAP, Bollinger, hacim, korelasyon/beta; bazıları araştırma ekranında. |
| 12 | Sinyal üretiminde yapay zekâ veya makine öğrenmesi kullanılıp kullanılmadığı açıklanmamıştır. | **Açıklandı** | Uygulama sinyal motorunda yapay zekâ/ML kullanılmıyor; deterministik kurallar kullanılıyor. |
| 13 | Varsa modelin türü, eğitimi, doğrulama yöntemi ve eğitim verisi açıklanmamıştır. | **Açıklandı** | Eğitilmiş sinyal modeli yok. ATR parametre seçimi araştırma özelliği; canlı model eğitimi değil. |
| 14 | Piyasa verisinin hangi borsa ve sağlayıcılardan alındığı tam olarak açıklanmamıştır. | **Uygulandı** | Canlı uygulama piyasa verisini Binance Spot ve USDⓈ-M uçlarından alır; harici karşılaştırmalar ayrı etiketlenir. |
| 15 | Veri yenileme sıklığı, gecikme ve fiyat birleştirme yöntemi açıklanmamıştır. | **Kısmi** | REST/WebSocket, olay zamanları ve bayat veri kontrolü var; tüm sağlayıcı gecikmelerini birleştiren çoklu kaynak saat senkronu yok. |
| 16 | Sinyal hesaplama kuralları, eşikler ve göstergelerin ağırlıkları açıklanmamıştır. | **Uygulandı** | Puan bileşenleri ve eşikler Ayarlar’da açıklanır. |
| 17 | Giriş, stop-loss ve hedef fiyatların nasıl hesaplandığı açıklanmamıştır. | **Uygulandı** | Stop/TP ATR/yapı kuralı, ücret/kayma varsayımları belgelenir. |
| 18 | Sinyal güven puanının tanımı ve hesaplama yöntemi açıklanmamıştır. | **Uygulandı** | 0–100 puan sezgisel uyum skorudur; olasılık olmadığı açıkça belirtilir. |
| 19 | Haber, sosyal duyarlılık, zincir üstü veri ve türev piyasa verisinin kullanımı doğrulanamamıştır. | **Kısmi** | Binance türev verisi, Alternative.me ve sunucuya bağlanan haber/Whale Alert adaptörleri var; abonelik/hesap verisi kullanıcı kurulumuna bağlı, sosyal katman yok. |
| 20 | Bağımsız denetim, geçmişe dönük test ve canlı performans doğrulamasına ilişkin yeterli kamuya açık kanıt bulunamamıştır. | **Kısmi** | Otomatik testler var; bağımsız denetim veya geniş örneklemli canlı performans doğrulaması yapılmadı. |
| 21 | Canlı spot ve vadeli piyasa fiyatlarını salt okunur biçimde izleme. | **Uygulandı** | Salt okunur halka açık Binance piyasa API’leri. |
| 22 | Coin arama, izleme listesi ve favori varlıklar. | **Uygulandı** | Arama ve cihaz içi favoriler. |
| 23 | Fiyat grafikleri ve mum grafiklerinde zaman dilimi seçimi. | **Uygulandı** | Mum grafiği, periyot seçimi ve özel periyotlar. |
| 24 | Long ve short senaryo kartları; yön, giriş alanı, geçersizlik seviyesi ve hedef bölgeleri. | **Uygulandı** | Yön, giriş, stop/geçersizlik ve beş hedef. |
| 25 | Sinyal geçmişi, açık/kapalı durum ve sonuç arşivi. | **Uygulandı** | Yerel sinyal geçmişi ve sanal işlem geçmişi. |
| 26 | Kullanıcının seçtiği varlıklar ve zaman dilimleri için analiz panosu. | **Uygulandı** | Parite ve zaman aralığı terminali. |
| 27 | Fiyat, hacim ve volatilite için eşik bazlı uyarılar. | **Kısmi** | Fiyat alarmı var; hacim ve volatilite için ayrı eşik alarmı yok. |
| 28 | BTC ve piyasa geneli için yön ve rejim özeti. | **Kısmi** | BTC yönü ve piyasa genişliği gösterilir; tam piyasa rejim sınıflandırması yok. |
| 29 | Teknik göstergelerin grafik üzerinde açılıp kapatılabilmesi. | **Kısmi** | Grafik göstergelerinin bir bölümü açılıp kapatılabilir; tüm analiz göstergeleri grafik bindirmesi değil. |
| 30 | Birden fazla zaman dilimini yan yana değerlendirme. | **Uygulandı** | Çoklu zaman dilimi analiz/teyit matrisi. |
| 31 | Piyasa tarayıcısı ve ölçütlere göre coin filtreleri. | **Uygulandı** | 250’ye kadar hacim/likidite filtreli radar. |
| 32 | İzleme listesi için özel alarm ve bildirim tercihleri. | **Kısmi** | Favori ve fiyat uyarısı var; favori başına ayrı bildirim tercihleri yok. |
| 33 | Sinyal ayrıntılarında gerekçeler, riskler ve karşı senaryoları gösterme. | **Uygulandı** | Gerekçe, engel, maliyet ve risk açıklaması. |
| 34 | Uygulama içi işlem yürütme, borsa hesabı bağlama ve varlık saklama olmadan analiz sunma. | **Uygulandı** | Borsa hesabı bağlama/emir gönderme/bakiye uçları bulunmuyor. |
| 35 | Her sinyalde zaman damgası, üretim fiyatı ve veri kaynağı gösterilmelidir. | **Uygulandı** | Sinyal zamanı, mum kapanışı, veri kaynağı ve olay zamanı kaydı. |
| 36 | Sinyal; ön izleme, teyit bekliyor, aktif, hedefe ulaştı, stop oldu, iptal ve süresi doldu gibi açık durumlar taşımalıdır. | **Kısmi** | Teyit bekliyor, aktif, TP aşaması, stop, iptal, tamamlandı ve süresi doldu; önizleme/ara durumların tümü ayrı yönetilmiyor. |
| 37 | Giriş aralığı tek fiyattan ziyade makul bir bölge olarak verilmeli; bölge dışı fiyat hareketinde sinyal yenilenmelidir. | **Kısmi** | Giriş referansı ve ATR uzaklık doğrulaması var; kullanıcıya geniş fiyat bandı olarak sunulmuyor. |
| 38 | Stop ve hedefler piyasa yapısı, volatilite ve likiditeye göre açıklanmalı; yalnızca sabit yüzde kullanılmamalıdır. | **Kısmi** | ATR ve yerel yapı, spread/derinlik filtreleri kullanılır; her seviyenin gerekçesi ayrı sayısal açıklamayla verilmiyor. |
| 39 | Risk/ödül oranı, ücret ve tahmini kayma hesaba katılarak gösterilmelidir. | **Uygulandı** | Ücret/kayma varsayımıyla net R/G. |
| 40 | Pozisyon büyüklüğü önerisi, kullanıcının tanımladığı risk yüzdesi ve stop mesafesine dayandırılmalıdır. | **Uygulandı** | Özkaynak riski ve stop uzaklığına göre boyut. |
| 41 | Kaldıraç bilgisi risk bağlamında verilmeli; yüksek kaldıraç teşvik edilmemelidir. | **Uygulandı** | Kaldıraç sanal ve üst sınırlandırılmış; spotta kaldıraç yok. |
| 42 | Aynı coin ve korelasyonlu coinlerde biriken toplam risk izlenmelidir. | **Eksik** | Açık pozisyonlarda korelasyonlu toplam portföy riski hesaplanmıyor. |
| 43 | Likidite, spread ve emir defteri derinliği zayıfsa sinyal puanı düşürülmeli veya sinyal engellenmelidir. | **Uygulandı** | Spread ve üst kademe derinlik filtreleri. |
| 44 | Hacim artışı, kırılım teyidi ve başarısız kırılım olasılığı birlikte değerlendirilmelidir. | **Kısmi** | Hacim oranı ve kırılım/yapı puanları var; başarısız kırılım olasılığı modellenmiyor. |
| 45 | Trend, yatay piyasa ve yüksek volatilite rejimleri birbirinden ayrılmalıdır. | **Kısmi** | Trend ve çoklu zaman uyumsuzluğu gösterilir; resmî rejim sınıflayıcı yok. |
| 46 | Sinyal güven puanı kalibre edilmiş olasılık olarak tanımlanmalı; başarı garantisi gibi sunulmamalıdır. | **Eksik** | Skor kalibre edilmiş başarı olasılığı değil; uygulama bunu gizlemeden bildiriyor. |
| 47 | Çelişen göstergeler veya zaman dilimleri varsa bu uyuşmazlık kullanıcıya gösterilmelidir. | **Uygulandı** | Zaman dilimi/BTC yön uyuşmazlığı engel ve faktörlerde görünür. |
| 48 | Veri gecikmesi, eksik mum, borsa kesintisi veya anormal fiyat durumunda sinyal üretimi durdurulmalıdır. | **Uygulandı** | Eksik/kapanmamış mum, bayat veri, API hatasında giriş doğrulaması durur. |
| 49 | Geleceği gören veri sızıntısı engellenerek geçmiş testler gerçekçi ücret ve kayma varsayımlarıyla yapılmalıdır. | **Kısmi** | Ayrık holdout/walk-forward ve ücret/kayma var; delist edilmiş varlık arşivi yok. |
| 50 | Başarı oranı, ortalama getiri, maksimum düşüş ve örneklem büyüklüğü birlikte raporlanmalıdır. | **Uygulandı** | Örneklem, net getiri, PF, düşüş ve Wilson aralığı raporlanır. |
| 51 | Borsa bağlantısı gerekiyorsa salt okunur piyasa verisiyle sınırlandırılmalı; emir yetkisi istenmemelidir. | **Uygulandı** | API anahtarı/işlem yetkisi istemez; yalnız piyasa verisi. |
| 52 | Piyasa verisinin kalite kontrolleri, zaman eşleştirmesi ve kaynaklar arası tutarlılığı yapılmalıdır. | **Kısmi** | Mum kalitesi/zaman eşleme kontrolü ve kaynak damgası var; borsalar arası tüm fiyat uzlaştırması yok. |
| 53 | BTC trendi, piyasa genişliği ve toplam piyasa koşulları rejim analizi içinde değerlendirilmelidir. | **Kısmi** | BTC yönü ve yükselen/düşen piyasa payı var; toplam piyasa endeksi/veri rejimi yok. |
| 54 | Coinlerin BTC ve piyasa endeksleriyle korelasyon ve beta ilişkisi ölçülmelidir. | **Kısmi** | BTC 30/90 gün korelasyon/beta var; daha geniş endeks korelasyonu yok. |
| 55 | Göreceli güç/zayıflık, coin performansının BTC’ye göre farkını göstermelidir. | **Uygulandı** | Coin getirisi BTC getirisiyle karşılaştırılır. |
| 56 | Vadeli piyasalarda fonlama oranı ve açık pozisyon değişimi bağlam verisi olarak sunulmalıdır. | **Uygulandı** | Fonlama, açık pozisyon, mark/endeks baz bağlamı. |
| 57 | Likidasyon yoğunluğu ve long/short dengesizliği, güvenilir veri varsa izlenmelidir. | **Kısmi** | Gözlenen Binance likidasyon olayları var; genel long/short dengesizliği yok. |
| 58 | Hacim, volatilite ve likidite ölçümleri sinyal filtresine dahil edilmelidir. | **Uygulandı** | Hacim, ATR/volatilite, spread ve derinlik filtreleri. |
| 59 | Haber ve önemli olay takvimi, analiz yanında ayrı bir bağlam katmanı olarak kullanılmalıdır. | **Kısmi** | Sunucu haber RSS adaptörü mevcut; sunucu ve dış bağlantı kurulumu gerekir. |
| 60 | Zincir üstü metrikler ancak kaynağı, kapsadığı ağ ve gecikmesi açıklanabiliyorsa gösterilmelidir. | **Kısmi** | Whale Alert adaptörü opsiyonel; ağ/varlık/sağlayıcı kapsamı ücretli anahtara bağlı. |
| 61 | Sosyal medya duyarlılığı kullanılırsa bot/spam etkisi ve örneklem sınırlamaları açıklanmalıdır. | **Eksik** | Sosyal medya bot/spam temizliği ve duyarlılık örneklemi yok. |
| 62 | Teknik göstergeler anlaşılır açıklamalar ve kullanıcı tarafından ayarlanabilir parametrelerle sunulmalıdır. | **Kısmi** | Yöntem açıklaması ve JSON kural editörü var; tüm gösterge parametreleri kullanıcı ayarlı değil. |
| 63 | Analiz, farklı zaman dilimlerinden gelen teyit ve çelişkileri birlikte göstermelidir. | **Uygulandı** | Birden fazla zaman dilimi ve çatışma göstergesi. |
| 64 | Kullanıcı; varlık, zaman dilimi, hacim, volatilite ve sinyal türü filtrelerini seçebilmelidir. | **Kısmi** | Varlık, zaman, hacim, yön ve favori filtresi var; volatilite için bağımsız tarayıcı filtresi yok. |
| 65 | Sanal portföy veya kâğıt üzerinde takip, sinyallerin işlem yapmadan izlenmesini sağlamalıdır. | **Uygulandı** | Sanal portföy, ücret/kayma ve kademeli hedef senaryosu. |
| 66 | Uyarılar gecikme, fiyat eşiği, yeni sinyal ve sinyal geçersizleşmesi için ayrı ayrı ayarlanabilmelidir. | **Kısmi** | Fiyat alarmı var; yeni sinyal/geçersizleşme/gecikme kategorileri ayrı yapılandırılmıyor. |
| 67 | Veri ve bildirim güvenliği için en az yetki, şeffaf gizlilik ve denetlenebilir erişim ilkeleri uygulanmalıdır. | **Kısmi** | İşlem yetkisi yok, token sunucu tarafında ve yerel depolama var; bağımsız gizlilik/güvenlik denetimi yok. |
| 68 | Sinyal performansı zaman içinde kalibre edilmeli; piyasa rejimine göre sapmalar izlenmelidir. | **Eksik** | Sinyal performansı rejime göre otomatik kalibre edilmiyor. |
| 69 | Delist edilmiş veya artık işlem görmeyen coinler geçmiş performans testlerinden çıkarılmamalıdır. | **Eksik** | Delist coin verisi saklanmıyor; güncel evrenle yapılan test survivor bias taşıyabilir. |
| 70 | Her sinyalin üretildiği veri ve kural sürümü yeniden üretilebilir biçimde kaydedilmelidir. | **Kısmi** | Sinyal arşivinde kural sürümü var; ham bütün veri paketi yeniden üretim için saklanmıyor. |
| 71 | Fiyat, mum kapanışı, sinyal üretimi ve bildirim zamanı ayrı ayrı tutulmalıdır. | **Uygulandı** | Sinyal üretim, mum kapanış ve gözlenen fiyat olaylarının zamanları ayrı tutulur. |
| 72 | Canlıya almadan önce gölge test ve kâğıt portföy ile ileriye dönük performans izlenmelidir. | **Kısmi** | Yerel kâğıt/sanal portföy var; uzun vadeli gölge çalışma bu teslimde başlatılmadı. |
| 73 | Kısa özet; sinyal yönü, nedenleri, geçersizlik seviyesi, risk ve zaman ufkunu tek bakışta vermelidir. | **Uygulandı** | Yön, gerekçe, geçersizlik/stop, risk, hedef ve zaman ufku detayda. |
| 74 | Test sonuçları örneklem büyüklüğü, ücret, kayma, maksimum düşüş ve piyasa koşullarıyla açıklanmalıdır. | **Uygulandı** | Test raporları maliyet, örneklem, PF, düşüş ve pencere bilgisi içerir. |
| 75 | Sinyal neden üretildi ve hangi koşulda iptal olur soruları kullanıcıya açıkça yanıtlanmalıdır. | **Uygulandı** | Analiz kartı gerekçe ve bekleme/iptal nedenlerini açıklar. |
| 76 | Haber katmanı analiz bağlamı sağlamalı, kendi başına kesin al/sat sinyali sayılmamalıdır. | **Kısmi** | Haber analiz bağlamı; işlem sinyali değil. Sunucu kurulumu gerekir. |
| 77 | Haberin kaynağı, yayın zamanı, ilgili coin ve olay türü gösterilmelidir. | **Kısmi** | RSS kaynak ve yayın saati var; ilgili coin eşleştirmesi tüm haberlerde güvenilir değil. |
| 78 | Aynı haberin farklı kaynaklardaki kopyaları gruplanarak tekrar etkisi azaltılmalıdır. | **Uygulandı** | Başlık tekrarları normalize edilerek birleştirilir. |
| 79 | Duyuru, ağ kesintisi, güvenlik olayı, regülasyon, token kilit açılımı ve makro takvim olayları sınıflandırılmalıdır. | **Kısmi** | Olay türü sınıflandırması var; makro takvim/token kilit açılımı kapsamı sınırlı. |
| 80 | Haberin güvenilirliği ve doğrulanma durumu belirtilmeli; söylentiler teyitli bilgi gibi sunulmamalıdır. | **Eksik** | Haber doğrulama durumu/söylenti teyidi için editoryal güven katmanı yok. |
| 81 | Olayın olası etkisi ve belirsizlik düzeyi sinyal gerekçesine bağlanmalıdır. | **Eksik** | Haber etkisi ve belirsizliği sayısal sinyal gerekçesine bağlanmıyor. |
| 82 | Önemli olay öncesi ve sonrasında volatilite uyarıları verilebilir. | **Eksik** | Olay öncesi/sonrası ayrı volatilite uyarıları yok. |
| 83 | Kullanıcı haber bildirimlerini kategori ve önem düzeyine göre ayarlayabilmelidir. | **Eksik** | Haber kategorisi/önem düzeyine özel kullanıcı bildirim tercihleri yok. |
| 84 | Veri akışı kesilirse son güncel veri zamanı gösterilmeli ve eski sinyaller otomatik olarak bayatlatılmalıdır. | **Kısmi** | Bayat akış işaretlenir; eski analizler girişte elenir. Cihaz kapalıyken süreklilik sunucu gerektirir. |
| 85 | Kullanıcı sinyali faydalı, geç, hatalı veya açıklaması yetersiz olarak işaretleyebilmelidir. | **Uygulandı** | Faydalı/geç/hatalı/açıklaması yetersiz geri bildirim yerel saklanır. |
| 86 | Analiz ve sinyal geçmişi CSV/PDF gibi biçimlerde dışa aktarılabilmelidir. | **Kısmi** | CSV ve JSON dışa aktarma var; PDF yok. |
| 87 | Fiyat sinyal yayımlandıktan sonra çok hareket etmişse sinyal geç kalmış olarak işaretlenmelidir. | **Uygulandı** | Son hareket, veri yaşı ve giriş sapması geç sinyali engeller. |
| 88 | Mum boyu, ATR ve son salınım mesafesine göre aşırı uzama/chase filtresi uygulanmalıdır. | **Uygulandı** | Son 6 mumda 2,5 ATR yönlü hareket filtresi. |
| 89 | Sinyalin üretildiği andan itibaren geçen süre ve fiyat sapması geçerlilik hesabına katılmalıdır. | **Uygulandı** | Sinyal yaşı, fiyat sapması ve invalidation hesaplanır. |
| 90 | Bildirim gönderilmeden hemen önce piyasa verisi yenilenip sinyal koşulları yeniden doğrulanmalıdır. | **Kısmi** | Sanal işlem açarken anlık doğrulama var; push gönderimi öncesi bağımsız sinyal tekrarı yok. |
| 91 | Giriş alanı kaçırılmışsa eski seviyeden işlem önerilmemeli; sinyal iptal edilmeli veya yeni kurulum beklenmelidir. | **Uygulandı** | Kaçan giriş, stop/hedef aşımı veya eski fiyat yeniden kullanılamaz. |
| 92 | Düzeltme/pullback bekleme senaryosu ve teyit koşulları açıkça sunulmalıdır. | **Kısmi** | Geri çekilme bekle uyarısı var; ayrı teyit emir senaryosu yok. |
| 93 | Kırılım sonrası retest veya devam teyidi gibi alternatif giriş koşulları ayrı gösterilmelidir. | **Eksik** | Retest/alternatif giriş algoritması üretilmiyor. |
| 94 | Sinyal geç kalmış, uygun giriş bekleniyor veya geçersiz gibi net etiketler taşımalıdır. | **Uygulandı** | Geç/izle/bekle/uygun engel etiketleri. |
| 95 | Analiz yalnızca mevcut yönü anlatmamalı; belirli zaman ufkunda olası fiyat bölgelerini ve senaryoları ileriye dönük tahmin etmelidir. | **Kısmi** | 1/4/12 mum için geçmiş ampirik aralık; tahmin modeli değil ve bunu arayüz açıkça söyler. |
| 96 | Tahmin ufku açıkça belirtilmeli; kısa, orta ve daha uzun vade tahminleri birbirine karıştırılmamalıdır. | **Uygulandı** | Ufuk mum ve süre olarak gösterilir. |
| 97 | Tek bir kesin hedef yerine baz, yükseliş ve düşüş senaryoları olasılık/belirsizlik aralıklarıyla sunulmalıdır. | **Kısmi** | Geçmiş %20/50/80 dağılımı var; baz/boğa/ayı senaryosu olasılık modeli değil. |
| 98 | Beklenen giriş bölgesi, hedef bölgeleri ve tahmini geçersizlik seviyesi önden tanımlanmalıdır. | **Uygulandı** | Giriş, beş hedef ve geçersizlik seviyesi tanımlı. |
| 99 | Tahminin güven seviyesi geçmişte aynı koşullardaki kalibrasyonla desteklenmeli ve garanti gibi sunulmamalıdır. | **Eksik** | Tahmin güveni rejime göre kalibre edilmiş değil. |
| 100 | Coin tarama evreni en az 250 bilinen ve yeterli hacme sahip varlıktan oluşmalıdır. | **Kısmi** | En fazla 250 bilinen USDT paritesi; 250 koşula uyan parite her an bulunmayabilir, sayı doldurulmaz. |
| 101 | Hacim eşiği kullanıcı tercihine göre tanımlanmalı; önceki kapsamda 24 saatlik en az 10 milyon USDT hacim ölçütü yer almıştır. | **Uygulandı** | 24 saat hacim eşiği kullanıcı ayarlı; 10 milyon USDT varsayılan. |
| 102 | Düşük likiditeli, yeni listelenmiş veya fiyat/veri kalitesi şüpheli coinler ayrıca işaretlenmeli ya da dışlanmalıdır. | **Kısmi** | Likidite/spread filtresi var; yeni liste yaşı ve fiyat anomalisi sınıflandırması sınırlı. |
| 103 | Coinlerin BTC ile 30 ve 90 günlük korelasyon/beta ilişkisi ölçülmeli; BTC yönü analizde bağlam olarak kullanılmalıdır. | **Uygulandı** | BTC 30/90 günlük korelasyon/beta ve BTC yön filtresi. |
| 104 | Coin evreni yalnızca hacme göre değil, piyasa değeri, borsa sayısı, spread ve sürekli işlem geçmişiyle de doğrulanmalıdır; stablecoin ve sarılmış varlıklar ayrı ele alınmalıdır. | **Kısmi** | Stablecoin/sarılmış varlıklar dışlanır; piyasa değeri ve borsa sayısı kaynağı yok. |
| 105 | 250 coin tarandıktan sonra 10–20 izleme adayı gösterilebilir; aktif sinyal sayısı piyasa koşullarına bağlı olmalı, kota doldurmak için yapay sinyal üretilmemelidir. | **Kısmi** | Uygun analizleri puanla sıralar; tam sabit 10–20 aday sunumu yok, sinyal uydurulmaz. |
| 106 | 250 coin tarama evrenidir; öneri listesi sabit sayıya zorlanmamalı, yalnızca koşulları karşılayan adayları göstermelidir. | **Uygulandı** | Aday adedi sabitlenmez; yalnız koşulu geçenler gösterilir. |
