'use strict';
(function(root){
 function create({max=5000,ttlMs=86400000,now=()=>Date.now()}={}){
  const rows=[];
  function add(s,{source='Binance REST',ruleVersion='crypto106-rules-1.0.0'}={}){
   if(!s||!s.symbol||!['spot','futures'].includes(s.market)||![1,-1].includes(s.dir)||![s.entry,s.stop,s.tp1,s.tp2,s.tp3,s.tp4,s.tp5].every(Number.isFinite))throw Error('Sinyal arşivi girdisi geçersiz');
   const id=[s.market,s.symbol,s.tf,s.candleEnd].join(':');let row=rows.find(x=>x.id===id);if(row)return row;
   row={id,symbol:s.symbol,market:s.market,tf:s.tf,dir:s.dir,entry:s.entry,stop:s.stop,targets:[s.tp1,s.tp2,s.tp3,s.tp4,s.tp5],score:s.score,createdAt:s.at||now(),candleEnd:s.candleEnd,source,ruleVersion,status:'TEYİT BEKLİYOR',stage:0,events:[],expiresAt:(s.at||now())+ttlMs};rows.unshift(row);rows.length=Math.min(rows.length,max);return row;
  }
  function observe(market,symbol,price,at=now()){
   if(!Number.isFinite(price)||price<=0)return [];
   const changed=[];
   for(const x of rows){if(x.market!==market||x.symbol!==symbol||['HEDEF TAMAMLANDI','STOP','İPTAL','SÜRESİ DOLDU'].includes(x.status))continue;
    const before=x.status;if(at>=x.expiresAt){x.status='SÜRESİ DOLDU';x.events.push({at,status:x.status,price});}
    else if(x.status==='TEYİT BEKLİYOR'){
     if((price-x.stop)*x.dir<=0){x.status='İPTAL';x.events.push({at,status:x.status,price});}
     else if((price-x.entry)*x.dir>=0){x.status='AKTİF';x.events.push({at,status:x.status,price});}
    }else if((price-x.stop)*x.dir<=0){x.status='STOP';x.events.push({at,status:x.status,price});}
    else if(x.stage<x.targets.length&&(price-x.targets[x.stage])*x.dir>=0){x.stage++;x.status=x.stage===x.targets.length?'HEDEF TAMAMLANDI':'AKTİF';x.events.push({at,status:x.stage===x.targets.length?x.status:'TP'+x.stage,price});}
    if(x.status!==before||x.events.at(-1)?.at===at)changed.push(x);
   }return changed;
  }
  function list(){return rows.map(x=>({...x,targets:[...x.targets],events:x.events.map(e=>({...e}))}));}
  function restore(items=[]){rows.length=0;for(const x of items.slice(0,max))if(x&&typeof x.id==='string'&&Array.isArray(x.targets)&&Array.isArray(x.events))rows.push(x);return list();}
  return{add,observe,list,restore};
 }
 const api={create};root.Crypto106SignalHistory=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
